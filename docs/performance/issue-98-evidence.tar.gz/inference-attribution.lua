-- DIAGNOSTIC ONLY: suppress the existing native successful-signature increment
-- to explain native/KL inference-counter differences. Not an adopted change.
local E=require('prolog_engine')
local inc=E.incinfs
local suppressed=0
E.incinfs=function()
  local info=debug.getinfo(2,'Sl')
  if info.source:match('typecheck_native%.lua$') and info.currentline == 458 then
    suppressed=suppressed+1
    return
  end
  return inc()
end
local report=require('bench.typecheck_harness').run('diagnostic')
print('SUPPRESSED_SIGNATURE_INCREMENTS',suppressed)
