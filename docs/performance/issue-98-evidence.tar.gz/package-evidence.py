from pathlib import Path
import datetime,gzip,hashlib,io,json,re,statistics,tarfile
root=Path.cwd();work=root/'.work/issue98';docs=root/'docs/performance'
assert json.loads((work/'diagnostics-complete.json').read_text())['result']=='PASS'
assert json.loads((work/'puc54-complete.json').read_text())['result']=='PASS'
rows=[];stats={};driver={}
for label in ['release','exact']:
 s=json.loads((work/f'final-{label}-time/summary.json').read_text());stats[label]=s
 driver[label]={}
 for state,v in s['states'].items():
  p=v['persistent'];rows.append(f"| {label} | {state} | {p['legacy_median']:.6f} | {p['native_median']:.6f} | {p['median_ratio']:.3f} | {p['ratio_range'][0]:.3f}–{p['ratio_range'][1]:.3f} | {p['native_wins']}/3 |")
  vals=[json.loads(f.read_text())['report']['phases']['driver_compile'] for f in (work/f'final-{label}-time').glob(state+'-*-native.json') if '-prime' not in f.name]
  driver[label][state]=dict(samples=vals,median=statistics.median(vals),range=[min(vals),max(vals)])
metadata=dict(runtime_commit='b4504cb7d0b2a50f01089b765b403999caa9f405',diagnostic_commit='05367d685d4674c5931a14e0cff81f5b91df132f',timing=stats,native_driver_compile_cpu=driver,validation=dict(port_checks_per_kernel=1833,community_judgments_per_kernel=154,native_require=True,pure_kl_prolog_control=True,puc='5.4.7',puc_native='explicitly rejected',standalone_bundles=True),limitations=['Uncontrolled busy host; engine comparison, no improvement-over-main or kernel A/B claim','Pure-KL switch independently controls Prolog primitives; general stdlib overrides still shared','Interactive mutation between loads excluded from FASL contract','Whole-query fallback/effect coverage beyond this corpus remains #72; detailed boundary allocation attribution remains #73','Numerical-owner prototype not adopted; no Lua numerical result inferred from Chez'])
(docs/'issue-98-statistics.json').write_text(json.dumps(metadata,indent=2)+'\n')
# Keep complete raw text receipts, including superseded and failed experiments.
# Exclude generated caches, downloaded archives and generated bundle binaries;
# their identities/provenance remain in the receipts and they remain locally.
allowed={'.json','.stdout','.stderr','.log','.txt','.diff','.py'}
files=[p for p in sorted(work.rglob('*')) if p.is_file() and p.suffix in allowed and p.name!='evidence-file-index.json' and '__pycache__' not in p.parts]
for name in ['compare-kernels.lua','inference-attribution.lua']:
 p=work/name
 if p.exists():files.append(p)
index=[];payload=[]
for p in files:
 raw=p.read_bytes()
 try:text=raw.decode('utf-8')
 except UnicodeDecodeError:continue
 text=text.replace(str(root),'<repo>').replace(str(Path.home()),'<home>')
 text=re.sub(r'/(?:private/)?var/folders/[^\s"\'\\]+','<private-temp>',text)
 assert '<home>' not in text
 data=text.encode();name=str(p.relative_to(work))
 index.append(dict(file=name,original_sha256=hashlib.sha256(raw).hexdigest(),portable_sha256=hashlib.sha256(data).hexdigest()))
 payload.append((name,data))
indexbytes=(json.dumps(dict(path_normalization=['checkout root to <repo>','home to <home>','ephemeral macOS temp paths to <private-temp>'],files=index),indent=2)+'\n').encode()
archive=docs/'issue-98-evidence.tar.gz'
with archive.open('wb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,data in [*payload,('evidence-file-index.json',indexbytes)]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(docs/'issue-98-evidence.sha256').write_text(sha+'  issue-98-evidence.tar.gz\n')
report='''# Issue 98: measurement foundation and exact-kernel qualification

The benchmark-repair slice is implemented, followed by exact ec16a9f adapter
qualification and file-contained cache mutation coverage. The default vendored
kernel remains release 715824a; no numerical representation change is adopted.

Implementation commits: `4fdacd2` and `b4504cb`; corrected diagnostic hooks:
`05367d6`. Base: fetched origin/main `c6c3a2280f6276e8b2b89b231257f50776c583ca`.
The original e3dec8b checkout and sibling worktrees were preserved.

## Qualification receipts

| Selected kernel | Port suite | Community suite, native require | Community suite, pure KL Prolog primitives | PUC Lua 5.4.7 golden |
| --- | --- | --- | --- | --- |
| Release 715824a | 1,833 / 0, 32 specs | 154 / 0 | 154 / 0 | 20 complete verdicts |
| Exact ec16a9f | 1,833 / 0, 32 specs | 154 / 0 | 154 / 0 | 20 complete verdicts |

Both kernels also passed ordinary default-native certification. Full-suite
runtime module hashes match the final implementation. The later diagnostic-only
harness change was checked against all 20 verdicts and off/cold/hit states in
both source and bundle configurations. Each kernel fixture was authenticated
against its pinned archive; all 23 ec16a9f KL files and all 73 community test files
match. Ten KL files are byte-identical between releases, twelve differ only in
generated names, and t-star contains the reviewed wrapper/helper changes.

The exact wrapper initially failed translation at its inline lazy-dereference
empty-list guard. The translator now supports that specific sentinel test; the
new fingerprint was accepted after reviewing datatype handport behavior. The
older 5596445 fixture remains intact. Derived helper closure, empty hypotheses,
accepted/rejected nested judgments, failed earlier alternatives, binding
rollback, runtime-error effects, missing drivers and strict fallback have focused
controls. Shared Prolog override mismatches preserve the selected KL definitions;
a pure-KL override switch supplies the independent primitive control.

Standalone bundles for both kernels passed accepted/rejected native judgments
from a separate directory with an intentionally missing external kernel path.
Source and bundle corpus matrices verified actual native routing and FASL
off/cold/hit, including retained prime processes.

Negative controls exited nonzero for a failed certification judgment (despite
the suite's final reset), missing input, changed input, and PUC strict-native
qualification. The certification driver now counts actual callbacks and reports
154/0 rather than the reset 0/0; failures and zero executed tests fail the driver.

The host command `lua` is a LuaJIT alias. Earlier reports labelled `puc-golden`
are retained as additional LuaJIT legacy controls and superseded for PUC claims.
Genuine PUC qualification uses the explicit Nix Lua 5.4.7 binary; reports assert
Lua 5.4 with no JIT. The first native-rejection probe under the alias exited zero
and is preserved with this explanation.

## Measurements

Timed source: `b4504cb`; 36 measured fresh processes and 12 private-cache primes,
three pairs per kernel/state and three requests per judgment. Every process
retains complete stdout/stderr, 20 full verdicts, inference counts, actual route,
cache outcome, effective runtime/compiler settings and input/source hashes.
Input identities match before/after every cohort. Allocation and profiling are
separate cohorts. The 431,741-inference inferred Y-combinator judgment is retained
alongside the much cheaper explicit-type judgment.

The table is the process CPU sum of the two persistent requests for every case.
Ratios are paired legacy/native ratios, summarized across three process pairs;
they are not ratios of the two displayed medians. These compare the existing
engines on this runtime. They do not measure a gain introduced by these commits
or a kernel A/B improvement. The host had ten CPUs and load averages around
37–40 at cohort start; all timing remains exploratory.

| Kernel | Cache | Legacy median seconds | Native median seconds | Paired ratio median | Paired ratio range | Native wins |
| --- | --- | --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'''

All paired samples and other phases (require, kernel load, initialise, fixture
loads, query reading, first judgments and persistent judgments) are in
`issue-98-statistics.json` and the raw receipts. Native-only driver compilation
has its own samples/medians there; legacy performs no native-driver translation.
This is an engine-paired matrix for each selected kernel, not an interleaved
release-versus-ec16a9f speed experiment.

Counters are stable within each engine across repetitions, processes and cache
states. Native exceeds legacy by two inferences for `map`, and by one for nine
signature-using cases; all other counts, including the inferred Y-combinator,
match. A separate diagnostic suppressing only the existing successful-signature
increment at typecheck_native.lua:458 exactly matches the legacy map for both
kernels. This explains the difference; production inference accounting and its
budget behavior are unchanged. No exact low-budget threshold parity is claimed.

The original Lua compiler profiling hook observed only the public export and
missed the captured local loader. Those reports are retained and superseded by
`corrected-*-diagnostic` and `corrected-*-bundle`. The corrected cold/off profiles
observe 89 defun compilations plus 55 expression compilations and 144 actual Lua
loads/compilations. Inclusive hooks overlap and must not be summed. GC-stopped
allocation diagnostics measure Lua heap growth, excluding FFI/native capacity;
GC-on heap occupancy is never labelled cumulative allocation.

## Cache boundary and remaining work

Off/cold/hit mutation controls pass for file-contained same-name macro/datatype
replacement, destroy, typed bridges, repeated failed loads with effects, and
changed nested dependencies. Nested loads run once. Interactive mutation between
loads remains excluded from the documented FASL contract; such sessions must use
FASL off. No broader replay or new cache format is adopted.

#72 remains the place for broader native coverage and fallback/effect conformance;
#73 retains detailed guard/materialization/import allocation attribution. This
corpus does not establish whole-port independence of shared general stdlib
overrides. The optional checked numerical owner/application remains unimplemented:
no Lua numerical-storage benefit was measured and no Chez gain is projected.

## Reproduction and evidence

Commands and exact measurement boundaries are in [typecheck-benchmarks.md](typecheck-benchmarks.md).
[Complete portable receipts](issue-98-evidence.tar.gz) include all accepted
samples, primes, complete outputs, commands, source hashes, archive checks,
negative controls and superseded experiments. Absolute checkout/home/temp paths
are normalized; the per-file index contains both original and portable hashes.
Generated bundle/cache binaries and downloaded archives remain in the local
`.work/issue98` directory; bundle hashes and archive identities are recorded.

Evidence archive SHA-256: `'''+sha+'''`.
'''
(docs/'issue-98-results.md').write_text(report)
print('evidence files',len(index),'compressed bytes',archive.stat().st_size,'sha256',sha)
