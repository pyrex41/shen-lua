from pathlib import Path
import os,subprocess,json,time
root=Path.cwd();out=root/'.work/issue98/validation-final-v2'
lua=(root/'.work/issue98/puc54-store-path.txt').read_text().strip()+'/bin/lua'
version=subprocess.check_output([lua,'-v'],text=True).strip();assert version.startswith('Lua 5.4'),version
print(version,flush=True)
for label,kernel in [('release',root/'klambda'),('exact',root/'test/fixtures/kernel-ec16a9f')]:
 env=os.environ.copy();env.update(SHEN_KL_DIR=str(kernel),SHEN_TYPECHECK_NATIVE='off',SHEN_PROLOG_ENGINE='legacy',SHEN_KERNEL_CACHE='off',SHEN_FASL='off',SHEN_BENCH_REPEATS='3')
 cmd=[lua,'bench/golden_typecheck.lua','compare'];t=time.monotonic()
 p=subprocess.run(cmd,env=env,capture_output=True,timeout=240)
 (out/(label+'-puc54-golden.stdout')).write_bytes(p.stdout);(out/(label+'-puc54-golden.stderr')).write_bytes(p.stderr)
 (out/(label+'-puc54-golden.json')).write_text(json.dumps(dict(command=cmd,version=version,settings={k:v for k,v in env.items() if k.startswith('SHEN_')},elapsed=time.monotonic()-t,exit=p.returncode),indent=2)+'\n')
 assert p.returncode==0,p.stderr
 report=json.loads(next(line[16:] for line in p.stdout.decode().splitlines() if line.startswith('SHEN_BENCH_JSON ')))
 assert report['runtime']['lua']=='Lua 5.4' and report['runtime']['jit']=='none'
 print(label+' PUC 5.4 complete golden pass',flush=True)
env.update(SHEN_TYPECHECK_NATIVE='require',SHEN_PROLOG_ENGINE='native')
p=subprocess.run([lua,'bench/typecheck_time.lua'],env=env,capture_output=True,timeout=60)
(out/'puc54-require-rejected.stdout').write_bytes(p.stdout);(out/'puc54-require-rejected.stderr').write_bytes(p.stderr)
(out/'puc54-require-rejected.json').write_text(json.dumps(dict(command=[lua,'bench/typecheck_time.lua'],version=version,exit=p.returncode,expected='nonzero'),indent=2)+'\n')
assert p.returncode!=0 and b'require mode needs the native dispatcher' in p.stderr,p.stderr
(root/'.work/issue98/puc54-complete.json').write_text(json.dumps(dict(result='PASS',version=version,legacy_goldens=['release','exact'],strict_native='explicitly rejected'))+'\n')
