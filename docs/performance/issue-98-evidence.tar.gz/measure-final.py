import json,os,subprocess,time
from pathlib import Path
root=Path.cwd();work=root/'.work/issue98';validation=work/'validation-final-v2'
start=time.monotonic()
while not (validation/'complete.json').exists():
 if time.monotonic()-start>900: raise RuntimeError('validation completion deadline')
 try:os.kill(82404,0)
 except ProcessLookupError:raise RuntimeError('validation stopped without a PASS receipt')
 time.sleep(2)
print('validation complete; starting isolated final cohorts',flush=True)
for label,kernel in [('release',root/'klambda'),('exact',root/'test/fixtures/kernel-ec16a9f')]:
 env=os.environ.copy();env['SHEN_KL_DIR']=str(kernel)
 for mode,pairs,states in [('time',3,['off','cold','hit']),('diagnostic',1,['off']),('alloc',1,['off'])]:
  out=work/f'final-{label}-{mode}'
  cmd=['python3','bench/run_typecheck.py','--mode',mode,'--pairs',str(pairs),'--repeats','3','--states',*states,'--out',str(out)]
  p=subprocess.run(cmd,env=env,timeout=600)
  if p.returncode:raise RuntimeError(str(cmd)+' failed')
 env['SHEN_BENCH_BUNDLE']=str(validation/(label+'-bundle.lua'))
 cmd=['python3','bench/run_typecheck.py','--mode','diagnostic','--pairs','1','--states','off','cold','hit','--out',str(work/f'final-{label}-bundle')]
 p=subprocess.run(cmd,env=env,timeout=300)
 if p.returncode:raise RuntimeError(label+' bundle corpus failed')
(work/'measurements-complete.json').write_text(json.dumps(dict(result='PASS',commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))+'\n')
