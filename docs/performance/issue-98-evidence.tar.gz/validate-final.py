import hashlib,json,os,signal,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'.work/issue98/validation-final-v2';out.mkdir(exist_ok=False)
source_files=[*root.glob('*.lua'),*root.glob('bench/*.*'),*root.glob('test/*_spec.lua'),root/'scripts/run-tests.lua',root/'build/make-bundle.lua']
before={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files if p.is_file()}
(out/'source-hashes.json').write_text(json.dumps(before,indent=2)+'\n')
def run(name,cmd,overrides,expected=0,timeout=240):
 env=os.environ.copy(); env.update(SHEN_KERNEL_CACHE=str(out/'kernel'),SHEN_FASL_DIR=str(out/'fasl'))
 env.update(overrides);t=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  p=subprocess.Popen(cmd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();code='TIMEOUT'
 receipt=dict(command=cmd,settings={k:v for k,v in env.items() if k.startswith('SHEN_') or k=='LUA'},elapsed=time.monotonic()-t,exit=code,expected=expected)
 (out/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,code,flush=True)
 if code!=expected:raise RuntimeError(name+' failed')
for label,kernel in [('release',root/'klambda'),('exact',root/'test/fixtures/kernel-ec16a9f')]:
 env=dict(SHEN_KL_DIR=str(kernel),LUA='luajit')
 run(label+'-test-all',['make','test-all'],env)
 run(label+'-require-certify',['luajit','run-kernel-tests.lua'],dict(env,SHEN_TYPECHECK_NATIVE='require',SHEN_FASL='off'))
 run(label+'-pure-kl-certify',['luajit','run-kernel-tests.lua'],dict(env,SHEN_TYPECHECK_NATIVE='off',SHEN_PROLOG_ENGINE='legacy',SHEN_PROLOG_PRIMITIVES='kl',SHEN_FASL='off'))
 run(label+'-puc-golden',['lua','bench/golden_typecheck.lua','compare'],dict(env,SHEN_TYPECHECK_NATIVE='off',SHEN_PROLOG_ENGINE='legacy',SHEN_KERNEL_CACHE='off',SHEN_FASL='off'),timeout=120)
 run(label+'-bundle-build',['luajit','build/make-bundle.lua',str(out/(label+'-bundle.lua'))],env)
run('routing-require',['luajit','test/typecheck_routing_spec.lua'],dict(SHEN_TYPECHECK_NATIVE='require',SHEN_FASL='off'))
# Negative certification: failure survives the suite's final reset and exits 1.
negative=out/'negative-suite';negative.mkdir()
(negative/'harness.shen').write_bytes((root/'tests/harness.shen').read_bytes())
(negative/'kerneltests.shen').write_text('(report "negative control" 1 2) (reset)\n')
run('negative-certification',['luajit','run-kernel-tests.lua'],dict(SHEN_TESTS_DIR=str(negative),SHEN_FASL='off'),expected=1)
# Missing and changed benchmark fixtures must fail authentication before timing.
control=out/'input-control';(control/'bench').mkdir(parents=True);(control/'tests').mkdir()
(control/'bench/verify_inputs.py').write_bytes((root/'bench/verify_inputs.py').read_bytes())
(control/'bench/fixtures.sha256').write_bytes((root/'bench/fixtures.sha256').read_bytes())
run('missing-input',['python3',str(control/'bench/verify_inputs.py')],{},expected=1)
(control/'tests/interpreter.shen').write_text('changed fixture\n')
run('changed-input',['python3',str(control/'bench/verify_inputs.py')],{},expected=1)
after={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files if p.is_file()}
assert before==after,'source changed during validation'
(out/'complete.json').write_text(json.dumps(dict(result='PASS',source_hashes_unchanged=True))+'\n')
