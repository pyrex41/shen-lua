local TN=require('typecheck_native')
local function read(p) local f=assert(io.open(p));local s=f:read('*a');f:close();return s end
local dir='.work/issue98/ShenOSKernel-43.1-ec16a9f/klambda/'
local p=assert(io.popen("ls klambda/*.kl"))
for path in p:lines() do
 local name=path:match('[^/]+$'); local a=TN.defuns_of(read(path)); local b=TN.defuns_of(read(dir..name))
 local diffs={};local n=0
 for k,v in pairs(a) do n=n+1;if not b[k] or TN.fingerprint(v)~=TN.fingerprint(b[k]) then diffs[#diffs+1]=k end end
 for k in pairs(b) do if not a[k] then diffs[#diffs+1]='ADDED:'..k end end
 table.sort(diffs); print(name,n,table.concat(diffs,','))
end
p:close()
