from pathlib import Path
import json,os,subprocess
root=Path.cwd();work=root/'.work/issue98';out=work/'validation-final-v2'
for label,kernel in [('release',root/'klambda'),('exact',root/'test/fixtures/kernel-ec16a9f')]:
 env=os.environ.copy();env['SHEN_KL_DIR']=str(kernel)
 cmd=['python3','bench/run_typecheck.py','--mode','diagnostic','--pairs','1','--states','off','cold','hit','--out',str(work/f'corrected-{label}-diagnostic')]
 subprocess.run(cmd,env=env,timeout=300,check=True)
 env['SHEN_BENCH_BUNDLE']=str(out/(label+'-bundle.lua'))
 cmd[-1]=str(work/f'corrected-{label}-bundle')
 subprocess.run(cmd,env=env,timeout=300,check=True)
 # True standalone load: no checkout modules or kernel directory can be found.
 standalone=out/'standalone';standalone.mkdir(exist_ok=True)
 smokeenv=os.environ.copy();smokeenv.update(SHEN_KL_DIR='/intentionally-missing-shen-kernel',SHEN_KERNEL_CACHE='off',SHEN_FASL='off',SHEN_TYPECHECK_NATIVE='require')
 code='local s=dofile('+json.dumps(str(out/(label+'-bundle.lua')))+'); s.boot{quiet=true}; local t=require("typecheck_native"); t.track_routes=true; assert(s.tostring(s.typecheck("(/. X (+ X 1))", "(number --> number)")) == "(number --> number)"); assert(t.last_route.engine == "native"); assert(s.typecheck("(+ 1 \\"bad\\")", "number") == false); print("standalone embedded kernel: native accepted/rejected judgments pass")'
 p=subprocess.run(['luajit','-e',code],cwd=standalone,env=smokeenv,capture_output=True,timeout=30)
 (out/(label+'-standalone.stdout')).write_bytes(p.stdout);(out/(label+'-standalone.stderr')).write_bytes(p.stderr)
 (out/(label+'-standalone.json')).write_text(json.dumps(dict(command=['luajit','-e',code],exit=p.returncode,cwd=str(standalone),kernel_dir=smokeenv['SHEN_KL_DIR']),indent=2)+'\n')
 assert p.returncode==0,p.stderr
 # Counter attribution control; it is a diagnostic and never a timing cohort.
 controlenv=os.environ.copy();controlenv.update(SHEN_KL_DIR=str(kernel),SHEN_KERNEL_CACHE='off',SHEN_FASL='off',SHEN_TYPECHECK_NATIVE='require',SHEN_BENCH_REPEATS='3')
 p=subprocess.run(['luajit','.work/issue98/inference-attribution.lua'],env=controlenv,capture_output=True,timeout=90)
 (work/(label+'-inference-attribution.stdout')).write_bytes(p.stdout);(work/(label+'-inference-attribution.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,p.stderr
 report=json.loads(next(line[16:] for line in p.stdout.decode().splitlines() if line.startswith('SHEN_BENCH_JSON ')))
 expected=json.loads((work/f'final-{label}-time/summary.json').read_text())['inference_counts']['legacy']
 counts={q['name']:q['inferences'] for q in report['queries']}
 assert counts==expected,(counts,expected)
 print(label+' inference deltas explained by existing successful-signature increment',flush=True)
(work/'diagnostics-complete.json').write_text(json.dumps(dict(result='PASS',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))+'\n')
