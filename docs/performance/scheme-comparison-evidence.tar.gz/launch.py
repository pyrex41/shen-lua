from pathlib import Path
import json,os,resource,subprocess,time,hashlib
r=Path.cwd();o=r/'.work/scheme-comparison';bundle=r/'.work/issue98/default-upstream/shen.lua';scheme=o/'shen-scheme-v0.52-pyrex41.5-macOS-bin/bin/shen-scheme';rows=[]
for pair in range(7):
 for engine in (['lua','scheme'] if pair%2==0 else ['scheme','lua']):
  env={k:v for k,v in os.environ.items() if not k.startswith('SHEN_')};env.update(SHEN_KERNEL_CACHE='off',SHEN_FASL='off',SHEN_TYPECHECK_NATIVE='require')
  if engine=='lua':cmd=['luajit','-e','local s=dofile('+json.dumps(str(bundle))+'); s.boot{quiet=true}; print("READY")']
  else:cmd=[str(scheme),'eval','-q','-e','(do (set *hush* false) (output "READY~%"))']
  before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,timeout=30);wall=time.monotonic()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
  row=dict(pair=pair,engine=engine,command=cmd,wall=wall,cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,exit=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),load=os.getloadavg())
  rows.append(row);(o/'launch.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0 and b'READY' in p.stdout
print('launch-to-ready: 7 matched pairs PASS')
