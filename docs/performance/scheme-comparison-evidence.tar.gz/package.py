from pathlib import Path
import gzip,hashlib,io,json,re,statistics,tarfile
root=Path.cwd();work=root/'.work/scheme-comparison';docs=root/'docs/performance';s=json.loads((work/'measured/summary.json').read_text())
launch=json.loads((work/'launch.json').read_text());s['launch']={}
for metric in ['cpu','wall']:
 v={e:[x[metric] for x in launch if x['engine']==e] for e in ['lua','scheme']};rat=[x/y for x,y in zip(v['lua'],v['scheme'])]
 s['launch'][metric]=dict(lua_median=statistics.median(v['lua']),scheme_median=statistics.median(v['scheme']),ratios=rat,median_ratio=statistics.median(rat))
v={}
for e in ['lua','scheme']:
 v[e]=[sum(q['cpu'] for q in json.loads(f.read_text())['report']['queries'] if q['request']>1 and q['name']!='interpreter-y-inferred') for f in sorted((work/'measured').glob('*-'+e+'.json'))]
rat=[x/y for x,y in zip(v['lua'],v['scheme'])];s['other_19']=dict(lua_median=statistics.median(v['lua']),scheme_median=statistics.median(v['scheme']),ratios=rat,median_ratio=statistics.median(rat))
(docs/'scheme-comparison-statistics.json').write_text(json.dumps(s,indent=2)+'\n')
# Store the exact accepted runner as well as generated Scheme driver and raw pairs.
(work/'accepted-compare_scheme.py').write_bytes((root/'bench/compare_scheme.py').read_bytes())
paths=[p for p in sorted(work.rglob('*')) if p.is_file() and p.suffix in {'.json','.ss','.py','.log','.stdout','.stderr','.diff','.md'} and 'shen-scheme-v' not in str(p.relative_to(work))]
archive=docs/'scheme-comparison-evidence.tar.gz';index=[]
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in paths:
  raw=p.read_bytes();txt=raw.decode().replace(str(root),'<repo>').replace(str(Path.home()),'<home>');txt=re.sub(r'/(?:private/)?var/folders/[^\s"\'\\]+','<private-temp>',txt);data=txt.encode();name=str(p.relative_to(work));index.append(dict(file=name,original_sha256=hashlib.sha256(raw).hexdigest(),portable_sha256=hashlib.sha256(data).hexdigest()))
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 data=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('index.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(docs/'scheme-comparison-evidence.sha256').write_text(sha+'  '+archive.name+'\n')
print(len(index),'receipts',sha)
