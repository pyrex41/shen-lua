(import (chezscheme) (shen-scheme runtime))
(let ([x (kl:read-from-string "(/. X X) : (A --> A)")]) (printf "PARSED ~s RAW ~s~%" x (kl:shen.typecheck (car x) (caddr x))))
