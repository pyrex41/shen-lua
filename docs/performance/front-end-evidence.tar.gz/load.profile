13%  APP
  -- 21%  prims.lua:1087
  -- 14%  [string]:56
  -- 14%  [string]:4
  -- 14%  prims.lua:1140
  --  7%  prims.lua:2234
  --  7%  [string]:161
  --  7%  prims.lua:155
  --  7%  prims.lua:1136
  --  7%  [string]:1
 7%  BIND1
  -- 75%  prolog_engine.lua:567
  -- 25%  prolog_engine.lua:579
 7%  f2
  -- 71%  profile.lua:9
  -- 14%  [string]:60
  -- 14%  prims.lua:1087
 4%  pcall
  -- 100%  runtime.lua:376
 3%  is_cons
  -- 100%  runtime.lua:42
 3%  cons
  -- 100%  runtime.lua:41
 3%  prolog:shen.system-S:56
  -- 67%  prolog:shen.system-S:57
  -- 33%  prolog:shen.system-S:152
 3%  f1
  -- 67%  prims.lua:1087
  -- 33%  prims.lua:273
 3%  MKFUN
  -- 100%  prims.lua:113
 3%  LZD
  -- 67%  prolog_engine.lua:208
  -- 33%  prolog_engine.lua:204
