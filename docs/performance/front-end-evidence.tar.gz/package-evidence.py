from pathlib import Path
import gzip,hashlib,io,json,re,statistics,subprocess,tarfile
root=Path.cwd();work=root/'.work/front-end';docs=root/'docs/performance'
labels=['map-spine','map-direct','native-walk','native-walk-repeat','native-walk-bundle','native-walk-bundle-repeat','walk-untraced-bundle']
cohorts={k:json.loads((work/k/'summary.json').read_text()) for k in labels}
loads={}
for build in ['final-source-cache-v2','final-bundle-cache']:
 loads[build]={}
 for p in sorted((work/build).glob('*-native.json')):
  loads[build][p.stem]=json.loads(p.read_text())['report']['loads']
validation=dict(port_checks=1858,specs=33,kernel_checks=154,strict_native_kernel=154,pure_kl_kernel=154,puc54_golden=20,source_bundle_states=['off','cold','hit'],standalone_bundle=True,diagnostic=True)
meta=dict(baseline_commit='bad0eba7c43292966c7db96b666627e67a0a5181',kernel='ec16a9fa4fc2e87e2aa336fb1ae30e8ac2266394',adopted_runtime_optimizations=[],cohorts=cohorts,validation=validation,load_receipts=loads,limitations=['Uncontrolled host; retained outliers', 'Inclusive diagnostic totals overlap', 'Qualification matrix timings excluded from performance claims', 'Different query repeat counts kept separate', 'FASL declaration replay may infer without dispatcher calls', 'Native and legacy paths share primitive overrides'])
# Every prototype is reverted; the only runtime edit is opt-in route logging.
for name in ['prims.lua','boot.lua','prolog_engine.lua','prolog_compile.lua']:
 assert (root/name).read_bytes()==subprocess.check_output(['git','show','HEAD:'+name])
binding={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.lua')}
binding.update({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'bench/typecheck_harness.lua',root/'bench/run_typecheck.py',root/'test/typecheck_routing_spec.lua']})
(work/'source-binding.json').write_text(json.dumps(dict(baseline=meta['baseline_commit'],hashes=binding,validation=validation),indent=2)+'\n')
# Exact instrumented source patch is reviewable alongside measured prototypes.
(work/'measurement.diff').write_bytes(subprocess.check_output(['git','diff','HEAD','--','*.lua','bench','test']))
allowed={'.json','.stdout','.stderr','.log','.diff','.py','.lua','.md','.profile','.txt'}
files=[p for p in sorted(work.rglob('*')) if p.is_file() and not p.is_symlink() and p.suffix in allowed and p.name not in ['shen.lua','shen-walk-untraced.lua','final-shen.lua'] and 'final-test' not in p.relative_to(work).parts and '__pycache__' not in p.parts]
# Normalize portable paths, preserving original and portable hashes in index.
def portable(txt):
 txt=txt.replace(str(root),'<candidate-repo>').replace(str(root.parent/'shen-lua-gap-guards'),'<baseline-repo>').replace(str(Path.home()),'<home>')
 return re.sub(r'/(?:private/)?var/folders/[^\s"\'\\]+','<private-temp>',txt)
(docs/'front-end-statistics.json').write_text(portable(json.dumps(meta,indent=2))+'\n')
archive=docs/'front-end-evidence.tar.gz';index=[]
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in files:
  raw=p.read_bytes()
  try:txt=raw.decode()
  except UnicodeDecodeError:continue
  data=portable(txt).encode();assert b'<home>' not in data
  name=str(p.relative_to(work));index.append(dict(file=name,original_sha256=hashlib.sha256(raw).hexdigest(),portable_sha256=hashlib.sha256(data).hexdigest()))
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 data=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('index.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(docs/'front-end-evidence.sha256').write_text(sha+'  '+archive.name+'\n')
print(len(index),'portable receipts;',archive.stat().st_size,'bytes;',sha)
