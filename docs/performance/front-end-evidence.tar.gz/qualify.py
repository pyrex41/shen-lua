from pathlib import Path
import os,subprocess,json
root=Path.cwd();out=root/'.work/front-end/qualification';out.mkdir(exist_ok=False)
base={k:v for k,v in os.environ.items() if not k.startswith('SHEN_')}
base.update(SHEN_KERNEL_CACHE='off',SHEN_FASL='off')
puc='<baseline-repo>/.work/arena-guards/puc54/bin/lua'
cases=[
 ('strict-native-kernel',['luajit','run-kernel-tests.lua'],{'SHEN_TYPECHECK_NATIVE':'require'}),
 ('pure-kl-kernel',['luajit','run-kernel-tests.lua'],{'SHEN_TYPECHECK_NATIVE':'off','SHEN_PROLOG_ENGINE':'legacy','SHEN_PROLOG_PRIMITIVES':'kl'}),
 ('puc54-golden',[puc,'bench/golden_typecheck.lua','compare'],{'SHEN_TYPECHECK_NATIVE':'off','SHEN_PROLOG_ENGINE':'legacy'}),
 ('diagnostic',['luajit','bench/typecheck_diagnostic.lua'],{'SHEN_TYPECHECK_NATIVE':'require','SHEN_BENCH_REPEATS':'1'}),
 ('standalone',['luajit','-e', 'local s=dofile('+json.dumps(str(root/'.work/front-end/final-shen.lua'))+');s.boot{quiet=true};local t=require("typecheck_native");t.track_routes=true;assert(s.tostring(s.typecheck("(/. X (+ X 1))","(number --> number)"))=="(number --> number)");assert(t.last_route.engine=="native");assert(s.typecheck("(+ 1 \\"bad\\")","number")==false);assert(t.last_route.engine=="native");print("standalone accepted/rejected native PASS")'],{'SHEN_KL_DIR':'/missing/kernel','SHEN_TYPECHECK_NATIVE':'require'}),
]
for label,cmd,settings in cases:
 env=base|settings
 cwd='/tmp' if label=='standalone' else root
 p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,timeout=240)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 (out/(label+'.json')).write_text(json.dumps(dict(command=cmd,cwd=str(cwd),settings={k:v for k,v in env.items() if k.startswith('SHEN_')},exit=p.returncode),indent=2)+'\n')
 print(label,p.returncode,flush=True)
 assert p.returncode==0,label
