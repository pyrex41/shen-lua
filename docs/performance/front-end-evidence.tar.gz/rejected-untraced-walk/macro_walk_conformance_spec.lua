-- Source eligibility must survive both cold compilation and a bytecode hit.
local function quote(s)return "'"..s:gsub("'","'\\''").."'" end
if arg[1]=='--child' then
 local P,R=require('boot'),require('runtime');P.load_kernel(false)
 assert(P.MACRO_WALK=='kl','changed/disabled source must retain KL walk')
 local effects={};local f=function(x)effects[#effects+1]=R.to_str(x);return x end;P.FA[f]=1
 P.F['shen.walk'](f,R.read_all('(a (b c))')[1])
 local expected=arg[2]=='changed' and '(a (b c))' or 'a;b;c;(b c);(a (b c))'
 assert(table.concat(effects,';')==expected,'selected KL body was not preserved')
 print('WALK_CONTROL',P.MACRO_WALK,P.MACRO_WALK_FINGERPRINT,P.KERNEL_CACHE_STATUS)
 return
end
local tmp=os.tmpname();os.remove(tmp);os.execute('mkdir -p '..quote(tmp))
local LUA=os.getenv('LUA') or 'luajit'
local R=require('runtime')
local function read(path)local f=assert(io.open(path,'rb'));local x=f:read('*a');f:close();return x end
local function write(path,x)local f=assert(io.open(path,'wb'));f:write(x);f:close() end
local files={'core','declarations','dict','extension-expand-dynamic','extension-features','extension-launcher','extension-namespaces','extension-programmable-pattern-matching','extension-type-annotations','init','load','macros','prolog','reader','sequent','stlib','sys','t-star','toplevel','track','types','writer','yacc'}
for _,name in ipairs(files) do
 local text=read('klambda/'..name..'.kl')
 if name=='macros' then
  local count;text,count=text:gsub('%(defun shen%.walk [^\n]*','(defun shen.walk (F X) (F X))')
  assert(count==1,'one selected walk definition')
 end
 write(tmp..'/'..name..'.kl',text)
end
local pass=0
for _,state in ipairs({'off','cold','hit','disabled'}) do
 local cache=state=='off' and 'off' or tmp..'/kernel-cache'
 local settings='SHEN_FASL=off SHEN_TYPECHECK_NATIVE=require SHEN_KERNEL_CACHE='..quote(cache)
 if state=='disabled' then settings=settings..' SHEN_MACRO_WALK=kl'
 else settings=settings..' SHEN_KL_DIR='..quote(tmp) end
 local cmd=settings..' '..quote(LUA)..' test/macro_walk_conformance_spec.lua --child '..(state=='disabled' and 'original' or 'changed')..' 2>&1'
 local pipe=assert(io.popen(cmd));local output=pipe:read('*a');local ok=pipe:close()
 assert(ok,output)
 assert(output:find('WALK_CONTROL',1,true),output)
 if state~='disabled' then assert(output:find('preserving kernel KL shen.walk',1,true),output) end
 if state=='hit' then assert(output:find('\thit',1,true),output) end
 print(state..': '..output);pass=pass+1
end
os.execute('rm -r '..quote(tmp))
print(string.format('macro_walk_conformance_spec: %d pass, 0 fail',pass))
