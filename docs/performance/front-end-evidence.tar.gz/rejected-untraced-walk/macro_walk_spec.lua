-- Compare the native walk with the selected kernel body, independently of
-- native/legacy typechecking (both share this source-loading primitive).
local shen=require('shen');shen.boot{quiet=true}
local P,R,C=shen.prims,require('runtime'),require('compiler')
local native=P.F['shen.walk']
local src=assert(io.open('klambda/macros.kl','rb'));local text=src:read('*a');src:close()
for _,form in ipairs(R.read_all(text)) do
 if R.is_cons(form) and form[1]==R.intern('defun') and form[2][1]==R.intern('shen.walk') then
  -- Keep recursive calls dynamic through the actual function table, as KL does.
  local alias=R.to_str(form):gsub('%(defun shen%.walk ','(defun spec.walk ')
  P.load_chunk(C.compile_top(R.read_all(alias)[1]),'walk-reference')()
 end
end
local reference=assert(P.F['spec.walk'])
local pass,fail=0,0
local function check(ok,label) if ok then pass=pass+1 else fail=fail+1;print('FAIL: '..label) end end
local function register(name,fn,n) P.F[name]=fn;P.FA[fn]=n;return fn end
P.F['y-or-n?']=function()return false end;P.FA[P.F['y-or-n?']]=1
local function run(walk,form,transform)
 P.F['shen.walk']=walk
 local effects={}
 local fn=function(x) effects[#effects+1]=R.to_str(x);if transform then return transform(x) end;return x end
 P.FA[fn]=1
 local ok,val=R.seg.pcall(walk,fn,form)
 return ok,ok and R.to_str(val) or P.F['error-to-string'](val),table.concat(effects,';'),val
end
for _,input in ipairs({'()','a','1','(a (b c) () (d))','(1 2 . tail)','((1 . tail) 3)'}) do
 local form=R.read_all(input)[1]
 local a,b,c=run(native,form);local d,e,f=run(reference,form)
 check(a==d and b==e and c==f,'kernel values/errors/postorder '..input)
end
local form=R.read_all('(1 (2 3) 4)')[1]
local ao,bo,co=run(native,form,function()return false end);local ar,br,cr=run(reference,form,function()return false end)
check(ao==ar and bo==br and co==cr,'false callback results are preserved')
local a,b,c,out=run(native,form);local d,e,f=run(reference,form)
check(a==d and b==e and c==f,'postorder for nested lists')
check(out~=form and out[2]~=form[2] and out[2][1]~=form[2][1],'fresh spines at every list node')
for _,walker in ipairs({native,reference}) do
 P.F['shen.walk']=walker
 local marker={}
 local effects={}
 local fn=function(x) effects[#effects+1]=R.to_str(x);if x==2 then error(marker,0) end;return x end;P.FA[fn]=1
 local before=R.seg.SD[1];local ok,err=R.seg.pcall(walker,fn,form)
 check(not ok and err==marker and table.concat(effects,';')=='1;2' and R.seg.SD[1]==before,'exception identity/order/segment cleanup')
end
P.F['shen.walk']=native
register('spec.walk-callback',function(x)return type(x)=='number' and x+1 or x end,1)
check(R.to_str(native(R.intern('spec.walk-callback'),form))=='(2 (3 4) 5)','symbol callback')
check(native(P.APP(P.F['+'],10),2)==12,'partial callback')
local original_map=P.F.map
for _,walker in ipairs({native,reference}) do
 P.F['shen.walk']=walker
 register('map',function(f,x)return 77 end,2)
 local id=function(x)return x end;P.FA[id]=1
 check(walker(id,form)==77,'custom map is observed')
 P.F.map=original_map
end
-- Changes made by a callback affect subsequent child traversal, including
-- redefinitions in the middle of the parent's map.
local function changing(walker,name)
 P.F['shen.walk']=walker;P.F.map=original_map
 local changed=false
 local f=function(x)
  if not changed then
   changed=true
   if name=='shen.walk' then register(name,function(_,v)return R.cons(R.intern('changed'),R.cons(v,R.NIL)) end,2)
   else register(name,function(_,_)return R.intern('changed') end,2) end
  end
  return x
 end;P.FA[f]=1
 local result=walker(f,form)
 P.F['shen.walk']=native;P.F.map=original_map
 return R.to_str(result)
end
for _,name in ipairs({'shen.walk','map'}) do
 check(changing(native,name)==changing(reference,name),'callback replacement of '..name)
end
P.F['shen.walk']=native
local id=function(x)return x end;P.FA[id]=1
local deep=1;for i=1,3000 do deep=R.cons(deep,R.NIL) end
local ok,result=R.seg.pcall(native,id,deep)
check(ok,'deep car recursion uses stack segments')
if ok then for i=1,3000 do result=result[1] end;check(result==1,'deep walk value') end
local wide=R.NIL;for i=1,20000 do wide=R.cons(i,wide) end
check(P.F.length(native(id,wide))==20000,'long cdr traversal uses bounded stack')
-- Nonempty source handlers continue to suppress the selected subtree.
local handler=R.read_all('((quote . ignored))')[1]
local quoted=R.read_all('(quote (a b))')[1]
check(P.F['shen.source-macro-walk'](id,quoted,handler)==quoted,'source form handler preserves protected subtree')
P.F['shen.walk']=native
print(string.format('macro_walk_spec: %d pass, %d fail',pass,fail));os.exit(fail==0 and 0 or 1)
