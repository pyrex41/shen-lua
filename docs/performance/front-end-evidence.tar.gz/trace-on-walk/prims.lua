-- prims.lua : build the runtime environment (function table F, apply/curry
-- machinery, KL primitives) and provide load/eval of KL forms.

local R = require("runtime")
local C = require("compiler")
local cons, is_cons, NIL = R.cons, R.is_cons, R.NIL
local Symbol, intern, is_symbol = R.Symbol, R.intern, R.is_symbol
local Excn, mkexcn = R.Excn, R.mkexcn
local Vmt = R.Vmt        -- absvector metatable (pure-array layout; shared with runtime.lua)
-- counted non-tail calls (runtime.lua stack segments, #93), written inline
-- where a native calls back into Shen code (a shared trampoline would look
-- like recursion to the trace recorder)
local SD, SEGRUN, SEG_FRAMES = R.seg.SD, R.seg.run, R.seg.FRAMES
local pcall = R.seg.pcall  -- restores the segment count on a caught error

local P = {}

local F  = {}            -- Shen/KL function table: name -> Lua function
local FA = setmetatable({}, {__mode="k"})  -- Lua function -> arity
local GLOBALS = {}       -- KL global variable namespace: name -> value
P.F, P.FA, P.GLOBALS = F, FA, GLOBALS

-- Allocation-attribution instrumentation (Part 1, THROWAWAY). Module-scope so
-- both the compiled-KL allocation sites (ENV.BIND freeze-thunks, MKFUN lambda
-- closures) and the native prolog prims share one counter table. Flag-gated;
-- counters are integer increments into a pre-existing table (zero allocation,
-- never touch shen.*infs*). Revert before shipping any Part-2 lever.
local APROF = os.getenv("SHEN_ALLOC_PROFILE") ~= nil
local AP = { lzy_calls=0, lzyoc_calls=0, lzy_cont=0, lzyoc_cont=0,
             deref_calls=0, deref_cons=0, occ_deref_calls=0, bind_calls=0,
             newpv_total=0, newpv_poolmiss=0, mkbind=0, mkbind_slots=0, mkfun=0,
             thaw_total=0 }
local AP_SLOTS = {}   -- BIND-thunk slot-count histogram: nslots -> count created
local AP_THAW  = {}   -- per-thunk thaw count (strong keys, profiling only): thunk -> n
P.AP, P.AP_SLOTS, P.AP_THAW = AP, AP_SLOTS, AP_THAW

-- ---- errors / exceptions -------------------------------------------------
local function ERR(msg) error(mkexcn(msg), 0) end

-- Lua-error -> Shen-speak translation. Lua runtime errors that escape
-- compiled Shen code read like VM internals ("attempt to call field 'foo'
-- (a nil value)"). Translate the common shapes into Shen terms, preserving
-- the original text in parentheses so nothing is hidden. Applied by TOEXCN
-- (so trap-error handlers see the translated message) and by the REPL's
-- top-level error display (repl.lua). Handles both the LuaJIT/Lua-5.1
-- message order ("attempt to call field 'foo' (a nil value)") and the
-- Lua-5.4 order ("attempt to call a nil value (field 'foo')").
local ERR_OPS = {
  { "call", function(ty, name)
      if ty == "nil" then
        if name then return name .. " is undefined" end
        return "attempt to call an undefined function"
      end
      return "attempt to call a " .. ty .. " value"
             .. (name and (" ('" .. name .. "')") or "") .. " as a function"
    end },
  { "index", function(ty, name)
      if ty == "nil" and name then return name .. " is nil and cannot be indexed" end
      return "attempt to index a " .. ty .. " value"
             .. (name and (" ('" .. name .. "')") or "")
    end },
  { "perform arithmetic on", function(ty, name)
      return "arithmetic on a " .. ty .. " value"
             .. (name and (" ('" .. name .. "')") or "") .. ": expected a number"
    end },
  { "concatenate", function(ty, name)
      return "string concatenation on a " .. ty .. " value"
             .. (name and (" ('" .. name .. "')") or "") .. ": expected a string"
    end },
  { "get length of", function(ty, name)
      return "length of a " .. ty .. " value"
             .. (name and (" ('" .. name .. "')") or "")
    end },
}

local function translate_error(msg)
  if type(msg) ~= "string" then return msg end
  -- strip the "chunkname:line: " position prefix for matching only
  local body = msg:match("^.-:%d+: (.*)") or msg
  for _, e in ipairs(ERR_OPS) do
    local op, fmt = e[1], e[2]
    local prefix = "^attempt to " .. op .. " "
    -- Lua 5.4 order: attempt to OP a TY value (KIND 'NAME')
    local ty, name = body:match(prefix .. "a (%a+) value %(%a+ '([^']+)'%)")
    if not ty then
      -- Lua 5.1 / LuaJIT order: attempt to OP KIND 'NAME' (a TY value)
      name, ty = body:match(prefix .. "%a+ '([^']+)' %(a (%a+) value%)")
    end
    if not ty then name = nil; ty = body:match(prefix .. "a (%a+) value") end
    if ty then return fmt(ty, name) .. " (Lua: " .. msg .. ")" end
  end
  local t1, t2 = body:match("^attempt to compare (%a+) with (%a+)")
  if t1 then
    return "comparison between a " .. t1 .. " and a " .. t2
           .. ": expected numbers (Lua: " .. msg .. ")"
  end
  local tt = body:match("^attempt to compare two (%a+) values")
  if tt then
    return "comparison between two " .. tt .. " values: expected numbers (Lua: " .. msg .. ")"
  end
  return msg
end
P.translate_error = translate_error

local function TOEXCN(e)
  if getmetatable(e) == Excn then return e end
  return mkexcn(translate_error(tostring(e)))
end
P.ERR = ERR

-- ---- apply / curry -------------------------------------------------------
local unpack = table.unpack or unpack
local function MKFUN(arity, fn) if APROF then AP.mkfun = AP.mkfun + 1 end; FA[fn] = arity; return fn end

-- Frozen-continuation thunks (from BIND / freeze) are represented as array
-- tables {fn, cap1, ..., capN} tagged with the Thunk metatable, NOT as Lua
-- closures. Reason: in LuaJIT every closed-over upvalue is a separate ~56-byte
-- GCupval box, so a freeze capturing 7 vars costs ~440 B as a closure but only
-- ~170 B as an 8-slot array table. Captures are never Lua nil (KL false/() are
-- non-nil values), so #t is a reliable length. thaw and APP's 0-arg path run a
-- thunk by calling t[1](t[2..#t]).
local Thunk = {}
local function runthunk(t)
  if APROF then AP.thaw_total = AP.thaw_total + 1; AP_THAW[t] = (AP_THAW[t] or 0) + 1 end
  return t[1](unpack(t, 2, #t))
end
P.Thunk = Thunk

local APP  -- fwd
local function PARTIAL(f, ar, have)
  local need = ar - #have
  local g
  g = function(...)
    local extra = {...}
    local all = {}
    for i=1,#have do all[i] = have[i] end
    local m = #have
    for i=1,select("#", ...) do all[m+i] = extra[i] end
    return f(unpack(all, 1, ar))
  end
  return MKFUN(need, g)
end

APP = function(f, ...)
  -- Fast path: the operand is overwhelmingly a Lua function (a compiled Shen
  -- function or a continuation/thunk). Check that first so the common case
  -- avoids the `is_symbol` getmetatable probe entirely. APP is ~13% of the
  -- typechecker's runtime, so this branch order matters.
  if type(f) == "function" then
    local n = select("#", ...)
    local ar = FA[f]
    if ar == nil or ar == n then     -- primitive/unknown-arity fn: assume exact
      return f(...)
    elseif n < ar then
      return PARTIAL(f, ar, {...})
    else
      local args = {...}
      local first = {}
      for i=1,ar do first[i] = args[i] end
      local r = f(unpack(first, 1, ar))
      local rest = {}
      for i=ar+1,n do rest[#rest+1] = args[i] end
      return APP(r, unpack(rest, 1, #rest))
    end
  end
  -- A frozen-continuation thunk applied with no args (KL `(thaw V)` sometimes
  -- routes here): run it; if over-applied, apply the result to the rest.
  if getmetatable(f) == Thunk then
    if select("#", ...) == 0 then return runthunk(f) end
    return APP(runthunk(f), ...)
  end
  -- Slow path: a symbol naming a function, or an error.
  if is_symbol(f) then
    local fn = F[f.name]
    if fn == nil then ERR("not a function: " .. f.name) end
    return APP(fn, ...)
  end
  ERR("attempt to apply a non-function")
end
P.APP, P.MKFUN, P.PARTIAL = APP, MKFUN, PARTIAL

-- ---- equality ------------------------------------------------------------
-- Lists are compared by walking the cdr spine in a loop and recursing only
-- into elements: the old car-and-cdr recursion was one Lua frame per cell,
-- which LuaJIT cannot trace (down-recursion aborts), so `=` on a list of N
-- cells ran interpreted. Deep `=` on list-shaped states is the hot path of
-- hash-map buckets and assoc lookups (issue #66).
local Cons = R.Cons
local function equal(a, b)
  if a == b then return true end
  if type(a) ~= "table" or type(b) ~= "table" then return false end
  local mt = getmetatable(a)
  if mt ~= getmetatable(b) then return false end
  if mt == Cons then
    repeat
      local x, y = a[1], b[1]
      if x ~= y and not equal(x, y) then return false end
      a, b = a[2], b[2]
      if a == b then return true end
    until getmetatable(a) ~= Cons or getmetatable(b) ~= Cons
    return equal(a, b)
  end
  -- vectors (pure-array layout: [1]=size, [i+2]=KL elt i)
  if mt == Vmt then
    local n = a[1]
    if n ~= b[1] then return false end
    for i=0,n-1 do
      local x, y = a[i+2], b[i+2]
      if x ~= y and not equal(x, y) then return false end
    end
    return true
  end
  return false
end
P.equal = equal

-- ---- primitive registration ---------------------------------------------
local function defprim(name, arity, fn)
  F[name] = fn
  FA[fn] = arity
  C.ARITY[name] = arity
end
P.defprim = defprim

local function tonum(x)
  if type(x) ~= "number" then ERR("not a number: " .. R.to_str(x)) end
  return x
end

-- arithmetic
defprim("+", 2, function(a,b) return tonum(a) + tonum(b) end)
defprim("-", 2, function(a,b) return tonum(a) - tonum(b) end)
defprim("*", 2, function(a,b) return tonum(a) * tonum(b) end)
defprim("/", 2, function(a,b) b=tonum(b); if b==0 then ERR("division by zero") end; return tonum(a)/b end)
-- PUC Lua 5.3+ tier: Lua gained an integer subtype whose int64 arithmetic
-- WRAPS on overflow; LuaJIT (and 5.1) compute on IEEE doubles. The kernel
-- relies on double behaviour — e.g. shen.hashkey takes the product of all
-- byte values of a symbol name (astronomically large) and shen.mod reduces
-- it by repeated subtraction, which only terminates if the product stayed a
-- positive (possibly inexact) float rather than wrapping to a negative int64.
-- So on 5.3+ the value-producing arithmetic primitives compute in the float
-- domain, reproducing the LuaJIT number model exactly (comparisons need no
-- coercion: int/float compares are exact in 5.3+). Under LuaJIT
-- math.tointeger is nil and the definitions above stay installed unchanged.
if math.tointeger then
  defprim("+", 2, function(a,b) return tonum(a) + 0.0 + tonum(b) end)
  defprim("-", 2, function(a,b) return tonum(a) + 0.0 - tonum(b) end)
  defprim("*", 2, function(a,b) return (tonum(a) + 0.0) * tonum(b) end)
  defprim("/", 2, function(a,b) b=tonum(b); if b==0 then ERR("division by zero") end; return (tonum(a)+0.0)/b end)
end
defprim(">", 2, function(a,b) return tonum(a) >  tonum(b) end)
defprim("<", 2, function(a,b) return tonum(a) <  tonum(b) end)
defprim(">=",2, function(a,b) return tonum(a) >= tonum(b) end)
defprim("<=",2, function(a,b) return tonum(a) <= tonum(b) end)
defprim("=", 2, function(a,b) return equal(a,b) end)

-- lists
defprim("cons", 2, function(a,b) return cons(a,b) end)
defprim("hd", 1, function(x) if not is_cons(x) then ERR("hd of non-cons") end return x[1] end)
defprim("tl", 1, function(x) if not is_cons(x) then ERR("tl of non-cons") end return x[2] end)
defprim("cons?", 1, function(x) return is_cons(x) end)

-- predicates
defprim("number?", 1, function(x) return type(x)=="number" end)
defprim("string?", 1, function(x) return type(x)=="string" end)
defprim("symbol?", 1, function(x) return is_symbol(x) end)
defprim("boolean?",1, function(x) return type(x)=="boolean" end)
defprim("not", 1, function(x) if type(x)~="boolean" then ERR("not: not boolean") end return not x end)
defprim("integer?",1, function(x) return type(x)=="number" and x==math.floor(x) and x~=math.huge and x~=-math.huge end)

-- symbols / strings
defprim("intern", 1, function(s)
  if type(s)~="string" then ERR("intern: not a string") end
  if s=="true" then return true elseif s=="false" then return false end
  return intern(s)
end)

-- `str` on a number and the printer are two surfaces on ONE rendering rule, so
-- there is one implementation of it, in runtime.lua. Keeping a second copy here
-- is how they diverged before; do not reintroduce one. See R.num_to_str for the
-- rule (exact %d inside int64, shortest-round-trip expanded positionally
-- outside it, shortest_float for non-integral and non-finite values).
local numToStr = R.num_to_str

defprim("str", 1, function(x)
  local t = type(x)
  if t=="number" then return numToStr(x)
  elseif t=="string" then return x          -- str of a string is the string (with quotes? Shen: str adds nothing here)
  elseif t=="boolean" then return x and "true" or "false"
  elseif is_symbol(x) then return x.name
  elseif x==NIL then ERR("str: cannot convert ()")
  else ERR("str: cannot convert") end
end)

defprim("cn", 2, function(a,b)
  if type(a)~="string" or type(b)~="string" then ERR("cn: not strings") end
  return a..b
end)
-- ---- strings are sequences of Unicode code points, held as UTF-8 ----------
-- (issue #80). A Shen string is a Lua string of UTF-8 bytes; the character
-- primitives (pos, tlstr, string->n, n->string, hdstr, explode, hash, the
-- reader) count CODE POINTS, not bytes. Pure-ASCII text stays on the old byte
-- fast path: every helper below first checks for a byte >= 0x80 and only then
-- walks the string as UTF-8. The checks are plain string.byte loops on
-- purpose: string.find with a pattern is not JIT-compiled by LuaJIT 2.1 and
-- aborts every trace that reaches it, which made an ASCII pos loop ~1000x
-- slower in testing. pos remembers the last string it scanned (first_high),
-- so a loop indexing one string scans it once.
--
-- INVALID UTF-8 is never an error and never loses data. Decoding is lenient:
-- any byte that does not begin a well-formed sequence -- a stray continuation
-- byte, a 0xC0/0xC1/0xF5..0xFF lead, a truncated sequence, an overlong form,
-- an encoded surrogate, anything above U+10FFFF -- is ONE character on its
-- own, consisting of that raw byte, whose code (string->n) is the byte value
-- 0x80..0xFF (the Latin-1 reading of that byte). pos/tlstr/explode keep the
-- raw byte, so (cn (hdstr S) (tlstr S)) == S always holds. The one thing that
-- does not round-trip is (n->string (string->n B)) for such a byte B: it
-- yields the UTF-8 encoding of U+0080..U+00FF, a different (valid) string.
-- The reader decodes source text the same way, so a stray Latin-1 byte in a
-- source string literal reads as the character of the same code.
--
-- n->string accepts integral 0..0x10FFFF except the surrogates
-- U+D800..U+DFFF and errors on anything else. Everything here is plain Lua
-- 5.1 string/arith code (no `utf8` library), so it runs identically on
-- LuaJIT 2.1 and PUC Lua 5.1..5.4.
local sbyte, ssub, schar = string.byte, string.sub, string.char
local mfloor = math.floor

-- first_high(s): byte index of the first byte >= 0x80 in s, or false if s is
-- pure ASCII. One-entry memo: strings are interned, so the hit test is a
-- pointer compare, and a loop calling pos on the same string scans it once.
local FH_S, FH_H = nil, false
local function first_high(s)
  if s == FH_S then return FH_H end
  local h = false
  for i = 1, #s do
    if sbyte(s, i) >= 0x80 then h = i; break end
  end
  FH_S, FH_H = s, h
  return h
end

-- u8dec(s, i) -> code point, byte length of the character at byte index i
-- (i <= #s). Lenient: an ill-formed sequence decodes as its first byte alone.
local function u8dec(s, i)
  local c = sbyte(s, i)
  if c < 0x80 then return c, 1 end
  if c < 0xC2 then return c, 1 end
  if c < 0xE0 then
    local c2 = sbyte(s, i + 1)
    if c2 and c2 >= 0x80 and c2 < 0xC0 then return (c - 0xC0) * 64 + (c2 - 0x80), 2 end
    return c, 1
  end
  if c < 0xF0 then
    local c2, c3 = sbyte(s, i + 1, i + 2)
    if c3 and c2 >= 0x80 and c2 < 0xC0 and c3 >= 0x80 and c3 < 0xC0 then
      local cp = (c - 0xE0) * 4096 + (c2 - 0x80) * 64 + (c3 - 0x80)
      if cp >= 0x800 and (cp < 0xD800 or cp > 0xDFFF) then return cp, 3 end
    end
    return c, 1
  end
  if c < 0xF5 then
    local c2, c3, c4 = sbyte(s, i + 1, i + 3)
    if c4 and c2 >= 0x80 and c2 < 0xC0 and c3 >= 0x80 and c3 < 0xC0
       and c4 >= 0x80 and c4 < 0xC0 then
      local cp = (c - 0xF0) * 262144 + (c2 - 0x80) * 4096 + (c3 - 0x80) * 64 + (c4 - 0x80)
      if cp >= 0x10000 and cp <= 0x10FFFF then return cp, 4 end
    end
  end
  return c, 1
end

-- u8enc(n) -> UTF-8 encoding of code point n, or nil if n is not an integral
-- Unicode scalar value (0..0x10FFFF minus the surrogates).
local function u8enc(n)
  if type(n) ~= "number" or n ~= mfloor(n) or n < 0 then return nil end
  if n < 0x80 then return schar(n) end
  if n < 0x800 then return schar(0xC0 + mfloor(n / 64), 0x80 + n % 64) end
  if n < 0x10000 then
    if n >= 0xD800 and n <= 0xDFFF then return nil end
    return schar(0xE0 + mfloor(n / 4096), 0x80 + mfloor(n / 64) % 64, 0x80 + n % 64)
  end
  if n <= 0x10FFFF then
    return schar(0xF0 + mfloor(n / 262144), 0x80 + mfloor(n / 4096) % 64,
                 0x80 + mfloor(n / 64) % 64, 0x80 + n % 64)
  end
  return nil
end

-- u8len(s): number of characters (code points / lone invalid bytes).
local function u8len(s)
  local h = first_high(s)
  if not h then return #s end
  local n, i, len = h - 1, h, #s
  while i <= len do
    local _, l = u8dec(s, i)
    i = i + l; n = n + 1
  end
  return n
end

-- u8pos(s, n): the n-th (0-based) character of s as a string, or nil when n
-- is out of range. ASCII prefix -> one byte substring.
local function u8pos(s, n)
  local len = #s
  if n >= len then return nil end            -- chars <= bytes
  local h = first_high(s)
  if not h or h > n + 1 then return ssub(s, n + 1, n + 1) end
  local i, k = h, h - 1                       -- k = index of char at byte i
  while i <= len do
    local _, l = u8dec(s, i)
    if k == n then return ssub(s, i, i + l - 1) end
    i = i + l; k = k + 1
  end
  return nil
end

-- u8tl(s): s without its first character (s non-empty).
local function u8tl(s)
  local c = sbyte(s, 1)
  if c < 0xC2 then return ssub(s, 2) end
  local _, l = u8dec(s, 1)
  return ssub(s, l + 1)
end

-- u8hd(s): the first character of s as a string (s non-empty).
local function u8hd(s)
  local c = sbyte(s, 1)
  if c < 0xC2 then return ssub(s, 1, 1) end
  local _, l = u8dec(s, 1)
  return ssub(s, 1, l)
end

-- u8explode(s): KL list of the characters of s.
local function u8explode(s)
  local acc = NIL
  local i = #s
  while i >= 1 do                     -- ASCII fast path, back to front
    local b = sbyte(s, i)
    if b >= 0x80 then break end
    acc = cons(schar(b), acc)
    i = i - 1
  end
  if i == 0 then return acc end
  acc = NIL
  local chars, len = {}, #s
  i = 1
  while i <= len do
    local _, l = u8dec(s, i)
    chars[#chars + 1] = ssub(s, i, i + l - 1)
    i = i + l
  end
  for j = #chars, 1, -1 do acc = cons(chars[j], acc) end
  return acc
end

-- u8codes(s): KL list of the character codes of s (string->n of each char).
local function u8codes(s)
  local acc = NIL
  local i = #s
  while i >= 1 do                     -- ASCII fast path, back to front
    local b = sbyte(s, i)
    if b >= 0x80 then break end
    acc = cons(b, acc)
    i = i - 1
  end
  if i == 0 then return acc end
  acc = NIL
  local cps, len = {}, #s
  i = 1
  while i <= len do
    local cp, l = u8dec(s, i)
    cps[#cps + 1] = cp
    i = i + l
  end
  for j = #cps, 1, -1 do acc = cons(cps[j], acc) end
  return acc
end

P.utf8 = { first_high = first_high, dec = u8dec, enc = u8enc, len = u8len,
           pos = u8pos, tl = u8tl, hd = u8hd, explode = u8explode, codes = u8codes }

local function nstr_error(n)
  local shown = type(n) == "number" and numToStr(n) or tostring(n)
  ERR("n->string: " .. shown .. " is not a Unicode code point (0..1114111, excluding surrogates)")
end

defprim("pos", 2, function(s,n)
  if type(s)~="string" then ERR("pos: not a string") end
  if type(n)~="number" or n < 0 or n ~= mfloor(n) then ERR("pos: index out of range") end
  local c = u8pos(s, n)
  if c == nil then ERR("pos: index out of range") end
  return c
end)
defprim("tlstr", 1, function(s)
  if type(s)~="string" then ERR("tlstr: not a string") end
  if #s == 0 then ERR("tlstr: empty string") end
  return u8tl(s)
end)
defprim("string->n", 1, function(s)
  if type(s) ~= "string" or #s == 0 then ERR("string->n: empty or non-string") end
  local c = sbyte(s, 1)
  if c < 0xC2 then return c end
  return (u8dec(s, 1))
end)
defprim("n->string", 1, function(n)
  if type(n) ~= "number" then ERR("n->string: not a number") end
  local ch = u8enc(n)
  if ch == nil then nstr_error(n) end
  return ch
end)
defprim("string->symbol", 1, function(s) return intern(s) end)

-- empty?
defprim("empty?", 1, function(x) return x==NIL end)

-- globals (dual namespace)
defprim("set", 2, function(sym, v)
  local key = is_symbol(sym) and sym.name or tostring(sym)
  GLOBALS[key] = v; return v
end)
defprim("value", 1, function(sym)
  local key = is_symbol(sym) and sym.name or tostring(sym)
  local v = GLOBALS[key]
  if v == nil then ERR("variable " .. key .. " has no value") end
  return v
end)

-- errors
defprim("simple-error", 1, function(msg) ERR(type(msg)=="string" and msg or R.to_str(msg)) end)
defprim("error-to-string", 1, function(e)
  if getmetatable(e)==Excn then return e.msg end
  return tostring(e)
end)

-- vectors (absvector: raw 0-indexed store of size n)
local FAILOBJ = intern("shen.fail!")
P.FAILOBJ = FAILOBJ
defprim("absvector", 1, function(n)
  local v = { [1] = n }
  for i=0,n-1 do v[i+2] = FAILOBJ end
  return setmetatable(v, Vmt)
end)
defprim("absvector?", 1, function(x) return getmetatable(x)==Vmt end)
-- An out-of-range read is an error (every in-range slot holds a value: the
-- fail object until written), so kernel code that probes past the end under
-- trap-error -- the vector printer's shen.iter-vector, shen.dict? -- sees
-- the boundary instead of a Lua nil.
local function addr_oob(v, i)
  ERR(R.to_str and (tostring(i) .. " is not a valid index") or "invalid index")
end
P.addr_oob = addr_oob
defprim("<-address", 2, function(v, i)
  local w = v[i+2]
  if w == nil then addr_oob(v, i) end
  return w
end)
defprim("address->", 3, function(v, i, x) v[i+2]=x; return v end)

-- freeze/thaw : thunks are 0-arity functions (kernel: (defun thaw (V) (V)))
-- Hot path in the Prolog/typechecker CPS: a thawed value is always a 0-arity
-- Lua closure (produced by `freeze` / BIND), so call it directly and skip the
-- full APP dispatch (symbol check, arity lookup, vararg packing). APP remains
-- the fallback for the rare symbol case.
defprim("thaw", 1, function(x)
  if getmetatable(x) == Thunk then return runthunk(x) end
  if type(x) == "function" then return x() end
  return APP(x)
end)

-- type : erased
defprim("type", 2, function(x, _ty) return x end)

-- eval-kl
local load_form  -- fwd (defined below)
defprim("eval-kl", 1, function(form) return P.eval(form) end)

-- get-time : (get-time Sym), Sym in {run, real, unix}
local t0_real = os.time()
defprim("get-time", 1, function(sym)
  local name = is_symbol(sym) and sym.name or tostring(sym)
  if name == "run" then return os.clock()
  else return os.time() - t0_real end   -- real / unix : wall seconds since boot
end)

-- ---- streams -------------------------------------------------------------
-- Stream objects carry a metatable so they are never confused with vectors
-- (absvector? requires getmetatable(x)==Vmt) or cons cells.
local Stream = {}
P.Stream = Stream
local function is_stream(x) return type(x)=="table" and getmetatable(x)==Stream end
P.is_stream = is_stream

local function mk_out_stream(writefn, closefn, name)
  return setmetatable({ kind="out", write=writefn, close=closefn, name=name }, Stream)
end
local function mk_in_stream(readfn, closefn, name)
  return setmetatable({ kind="in", readbyte=readfn, close=closefn, name=name, eof=false }, Stream)
end
P.mk_out_stream, P.mk_in_stream = mk_out_stream, mk_in_stream

-- 43.1 public character-stream interfaces. `pr` uses char-stream? to choose
-- between a fast (write-string) and a fallback (write-chars) path. write-chars
-- writes (string->n (pos S I)) per character with write-byte, which cannot
-- carry a code point above 0x7F (issue #80), so every output stream here is a
-- CHARACTER stream for pr: shen.write-string writes the string's UTF-8 bytes
-- as they are. write-byte stays a raw byte primitive.
defprim("char-stream?", 1, function(st) return is_stream(st) end)
defprim("write-string", 2, function(s, st)
  if not is_stream(st) or st.kind~="out" then ERR("pr: not an output stream") end
  if type(s) ~= "string" then ERR("pr: not a string") end
  st.write(s)
  return s
end)

-- write-byte (N STREAM) -> N : write a single byte to an output stream
defprim("write-byte", 2, function(n, st)
  if not is_stream(st) or st.kind~="out" then ERR("write-byte: not an output stream") end
  st.write(string.char(n))
  return n
end)

-- raw next byte of an input stream, honouring one byte of pushback (used by
-- the UTF-8 decoder below when a sequence turns out to be ill-formed).
local function stream_byte(st)
  local pb = st.pb
  if pb then st.pb = nil; return pb end
  if st.eof then return -1 end
  local b = st.readbyte()
  if b == nil then st.eof = true; return -1 end
  return b
end

-- read-byte (STREAM) -> N | -1 at EOF
defprim("read-byte", 1, function(st)
  if not is_stream(st) or st.kind~="in" then ERR("read-byte: not an input stream") end
  return stream_byte(st)
end)

-- stream_char(st) -> code point of the next character of st, or -1 at EOF.
-- Lenient like u8dec: an ill-formed sequence yields its lead byte's value and
-- the offending byte is pushed back to start the next character.
local function stream_char(st)
  local c = stream_byte(st)
  if c < 0xC2 or c > 0xF4 then return c end      -- ASCII, EOF, or lone byte
  local need = c < 0xE0 and 1 or (c < 0xF0 and 2 or 3)
  local cp = c < 0xE0 and c - 0xC0 or (c < 0xF0 and c - 0xE0 or c - 0xF0)
  for _ = 1, need do
    local b = stream_byte(st)
    if b < 0x80 or b > 0xBF then
      if b ~= -1 then st.pb = b end
      return c
    end
    cp = cp * 64 + (b - 0x80)
  end
  if (need == 2 and (cp < 0x800 or (cp >= 0xD800 and cp <= 0xDFFF)))
     or (need == 3 and (cp < 0x10000 or cp > 0x10FFFF)) then
    return c        -- overlong / surrogate / out of range: lead byte alone
  end
  return cp
end

-- shen.my-read-byte (reader.kl) feeds the reader behind `read` and `lineread`.
-- The reader consumes character codes (it rebuilds text with n->string), so
-- the native override (install_native_stdlib) reads one UTF-8 character with
-- stream_char and returns its code point; read-byte on the same stream still
-- sees raw bytes.
-- read-unit-string: one character as a string ("" at EOF).
defprim("read-unit-string", 1, function(st)
  if not is_stream(st) or st.kind~="in" then ERR("read-unit-string: not an input stream") end
  local cp = stream_char(st)
  if cp == -1 then return "" end
  return u8enc(cp) or schar(cp)
end)

-- Keep the pre-43 hook names available to older user code. The 43.1 kernel
-- itself uses only the public names above.
defprim("shen.char-stoutput?", 1, function(st) return is_stream(st) end)
defprim("shen.char-stinput?", 1, function(st) return is_stream(st) end)
defprim("shen.write-string", 2, function(s, st) return F["write-string"](s, st) end)
defprim("shen.read-unit-string", 1, function(st) return F["read-unit-string"](st) end)

-- A file name as `open` sees it: *home-directory*, which `cd` sets (sys.kl),
-- prepended as a plain string, as shen-scheme and shen-go do, so an absolute
-- name after a non-empty cd is joined too. Every native path that
-- reads a user file (read-file, read-file-as-*, the fasl `load`) resolves
-- through this too, so it opens the same file `open` would.
local function home_path(name)
  local home = GLOBALS["*home-directory*"]
  if type(home) ~= "string" or home == "" then
    return name
  end
  return home .. name
end
P.home_path = home_path

-- open (NAME DIRECTION) -> stream ; DIRECTION is symbol `in` or `out`
defprim("open", 2, function(name, dir)
  if type(name)~="string" then ERR("open: filename not a string") end
  local d = is_symbol(dir) and dir.name or tostring(dir)
  name = home_path(name)
  if d == "in" then
    local fh, e = io.open(name, "rb")
    if not fh then ERR("open: cannot open "..name.." ("..tostring(e)..")") end
    return mk_in_stream(function() local c = fh:read(1); return c and string.byte(c) or nil end,
                        function() fh:close() end, name)
  elseif d == "out" then
    local fh, e = io.open(name, "wb")
    if not fh then ERR("open: cannot open "..name.." ("..tostring(e)..")") end
    return mk_out_stream(function(s) fh:write(s) end, function() fh:close() end, name)
  else
    ERR("open: bad direction "..d)
  end
end)

-- close (STREAM) -> ()
defprim("close", 1, function(st)
  if is_stream(st) and st.close then st.close() end
  return NIL
end)

-- exit
defprim("exit", 1, function(n) io.stdout:flush(); os.exit(type(n)=="number" and n or 0) end)

-- Native reimplementation of the hottest Prolog dereference primitives.
-- These run ~6x/inference in the typechecker; as compiled KL each call pays
-- function-dispatch + per-step `<-address`/`shen.pvar?` indirection. The native
-- versions are tight Lua loops over the prolog binding vector (this is what the
-- shen-c and shen-rust ports do). shen.deref additionally does STRUCTURE SHARING
-- -- returning the original cons subtree unchanged when nothing dereffed -- which
-- the native C/Rust ports do NOT do, eliminating most of deref's cons allocation.
-- Installed after the kernel loads (overriding the compiled KL defuns in F).
-- A prolog variable is an absvector (pure-array layout, metatable Vmt): KL
-- index 0 (the `shen.pvar` tag) lives at slot [2], KL index 1 (the ticket) at
-- slot [3]. The binding for ticket t lives at prolog-vector KL-index t, i.e.
-- slot v[t+2], with shen.-null- meaning unbound.
function P.install_native_prolog()
  local shen_pvar = intern("shen.pvar")
  local shen_null = intern("shen.-null-")
  local getmt = getmetatable
  -- Allocation-attribution instrumentation (Part 1, THROWAWAY). Uses the
  -- module-scope AP/APROF (shared with ENV.BIND/MKFUN). `prof` is a single
  -- predictable-false branch when the flag is off.
  local prof = APROF
  local function is_pvar(x)
    return getmt(x) == Vmt and x[2] == shen_pvar
  end
  local function lazyderef(x, v)
    while getmt(x) == Vmt and x[2] == shen_pvar do
      local w = v[x[3]+2]
      if w == shen_null then return x end
      x = w
    end
    return x
  end
  local function deref(x, v)
    if prof then AP.deref_calls = AP.deref_calls + 1 end
    if is_cons(x) then
      local h0, t0 = x[1], x[2]
      local h = deref(h0, v)
      local t = deref(t0, v)
      if h == h0 and t == t0 then return x end   -- structure sharing: nothing changed
      if prof then AP.deref_cons = AP.deref_cons + 1 end
      return cons(h, t)
    elseif getmt(x) == Vmt and x[2] == shen_pvar then
      local w = v[x[3]+2]
      if w == shen_null then return x end
      return deref(w, v)
    else
      return x
    end
  end
  -- Native unification core (extends the native deref family). These are the
  -- hottest compiled-KL Prolog primitives; as KL each call pays F-table
  -- dispatch + per-step `<-address`/`shen.pvar?` (which in KL wraps a
  -- trap-error!) indirection. The native versions are tight Lua that call each
  -- other directly (no F-table round-trip) -- this is what shen-c's overwrite.c
  -- does. Semantics mirror klambda/prolog.kl EXACTLY (binding trail via the
  -- prolog vector, occurs check, freeze/thaw CPS continuations). None of these
  -- functions touch shen.*infs*, so the inference count is unchanged.
  --
  -- A continuation (KL `freeze`) is thawed after a successful bind; it may be a
  -- BIND-thunk table (from compiled KL callers) or a plain Lua closure (built
  -- by native lzy= below), so thaw handles both.
  local function thaw(c)
    if getmt(c) == Thunk then return runthunk(c) end
    if type(c) == "function" then return c() end
    return APP(c)
  end
  -- bindv: prolog-vector[ Var's ticket ] := Val  (KL <-address Var 1 = Var[3])
  local function bindv(var, val, vec) vec[var[3]+2] = val; return vec end
  -- unwind: undo a binding on backtrack, returning the (false) result through.
  local function unwind(var, vec, x) vec[var[3]+2] = shen_null; return x end
  -- bind!: bind, run the continuation; if it fails (false) undo the binding.
  local function bind_(var, val, vec, cont)
    if prof then AP.bind_calls = AP.bind_calls + 1 end
    bindv(var, val, vec)
    local w = thaw(cont)
    if w == false then return unwind(var, vec, w) end
    return w
  end
  local function occurs(var, x)
    if equal(var, x) then return true end
    if is_cons(x) then
      return occurs(var, x[1]) or occurs(var, x[2])
    end
    return false
  end
  -- lzy=  : lazy unification (no occurs check). X and Y are already lazyderef'd
  -- by the caller / by the recursive step. The tail continuation is a Lua
  -- closure (KL `freeze`) that lazyderefs the tails when thawed.
  local lzy
  lzy = function(x, y, v, cont)
    if prof then AP.lzy_calls = AP.lzy_calls + 1 end
    if equal(x, y) then return thaw(cont) end
    if is_pvar(x) then return bind_(x, y, v, cont) end
    if is_pvar(y) then return bind_(y, x, v, cont) end
    if is_cons(x) and is_cons(y) then
      local xt, yt = x[2], y[2]
      if prof then AP.lzy_cont = AP.lzy_cont + 1 end
      return lzy(lazyderef(x[1], v), lazyderef(y[1], v), v,
                 function() return lzy(lazyderef(xt, v), lazyderef(yt, v), v, cont) end)
    end
    return false
  end
  -- lzy=! : lazy unification WITH occurs check (mirrors shen.lzy=!).
  local lzyoc
  lzyoc = function(x, y, v, cont)
    if prof then AP.lzyoc_calls = AP.lzyoc_calls + 1 end
    if equal(x, y) then return thaw(cont) end
    if is_pvar(x) then
      if prof then AP.occ_deref_calls = AP.occ_deref_calls + 1 end
      if not occurs(x, deref(y, v)) then return bind_(x, y, v, cont) end
    end
    if is_pvar(y) then
      if prof then AP.occ_deref_calls = AP.occ_deref_calls + 1 end
      if not occurs(y, deref(x, v)) then return bind_(y, x, v, cont) end
    end
    if is_cons(x) and is_cons(y) then
      local xt, yt = x[2], y[2]
      if prof then AP.lzyoc_cont = AP.lzyoc_cont + 1 end
      return lzyoc(lazyderef(x[1], v), lazyderef(y[1], v), v,
                   function() return lzyoc(lazyderef(xt, v), lazyderef(yt, v), v, cont) end)
    end
    return false
  end
  -- pvar pooling (playbook D). Tickets are allocated/reclaimed in strict LIFO
  -- order: newpv bumps vec[3], gc-on-failure decrements it. A failed branch's
  -- pvar (the one whose ticket gc reclaims) is not part of any result -- success
  -- propagates x~=false so result pvars are never pooled -- so its 2-slot table
  -- can be recycled instead of GC'd + reallocated by the next newpv. pstk
  -- records, per ticket, the object created there so gc can reclaim it. A pooled
  -- pvar only ever has its [3] (ticket) overwritten; [1]=2 and [2]=shen.pvar are
  -- invariant, so reuse just rewrites the ticket. Scratch state is per-run, but
  -- vectors are used sequentially (never nested in one inference), so a global
  -- ticket-indexed stack is safe.
  --
  -- RESIDUAL RISK (validated empirically: 42 and 42 suites 134/134 + the typecheck
  -- inference count is byte-identical with and without pooling, so no exercised
  -- unification path is perturbed): recycling reuses the table OBJECT, not just
  -- the ticket. This is unsafe only if a reclaimed-ticket pvar object is still
  -- live after its branch fails. The one construct that could do that is
  -- findall/shen.overbind, which snapshots derefed terms (shen.deref keeps
  -- UNBOUND pvars by identity) into a collector across backtracking; if such a
  -- snapshot retained a high-ticket unbound pvar that gc later reclaims, reuse
  -- would mutate it. The kernel's own type rules don't trigger this (hence the
  -- identical inference count), but heavy user-level findall over unbound logic
  -- vars is the boundary to re-validate before reusing this pool elsewhere.
  local pool = {}      -- freelist of recyclable {2, shen.pvar, ticket} tables
  local pstk = {}      -- pstk[ticket] = pvar object allocated at that ticket
  -- newpv: reuse a pooled pvar (or allocate), record it, clear its binding
  -- slot, and bump the vector's ticket counter (KL index 1 = slot [3]).
  local function newpv(vec)
    if prof then AP.newpv_total = AP.newpv_total + 1 end
    local n = vec[3]
    -- Per-query capacity: shen.prolog-vector allocates ONE absvector of
    -- (value shen.*prolog-memory*) slots per query, so the kernel's
    -- shen.nextticket writes slot n and the query dies once n reaches the
    -- vector size. Our absvector is a Lua table, and address-> is an
    -- unchecked store, so without this the vector would silently grow and a
    -- query that raises on every other port would answer here.
    local size = vec[1]
    if type(size) == "number" and n >= size then
      ERR("prolog vector index out of range: a single query may allocate at "
          .. "most " .. (size - 2) .. " variables (shen.*prolog-memory*)")
    end
    local np = #pool
    local pv = pool[np]
    if pv ~= nil then pool[np] = nil; pv[3] = n
    else
      if prof then AP.newpv_poolmiss = AP.newpv_poolmiss + 1 end
      pv = setmetatable({ [1] = 2, [2] = shen_pvar, [3] = n }, Vmt)
    end
    pstk[n] = pv
    vec[n+2] = shen_null
    vec[3] = n + 1
    return pv
  end
  -- gc: on backtrack (x==false) reclaim the most recent ticket and recycle its
  -- pvar object; else pass x through.
  local function gc(vec, x)
    if x == false then
      local n = vec[3] - 1
      vec[3] = n
      local pv = pstk[n]
      if pv ~= nil then pool[#pool+1] = pv; pstk[n] = nil end
    end
    return x
  end
  F["shen.pvar?"] = is_pvar;        FA[is_pvar] = 1
  F["shen.lazyderef"] = lazyderef;  FA[lazyderef] = 2
  F["shen.deref"] = deref;          FA[deref] = 2
  F["shen.bindv"] = bindv;          FA[bindv] = 3
  F["shen.unwind"] = unwind;        FA[unwind] = 3
  F["shen.bind!"] = bind_;          FA[bind_] = 4
  F["shen.occurs-check?"] = occurs; FA[occurs] = 2
  F["shen.lzy="] = lzy;             FA[lzy] = 4
  F["shen.lzy=!"] = lzyoc;          FA[lzyoc] = 4
  F["shen.newpv"] = newpv;          FA[newpv] = 1
  F["shen.gc"] = gc;                FA[gc] = 2
end

-- Native overrides of the hottest GENERAL-purpose kernel functions (the
-- officially-recommended "overwrite" peephole track; see Shen PortDeveloperNotes
-- and shen-cl's overwrite.lsp). Installed after the kernel loads, overriding the
-- compiled-KL defuns in F. A 42-suite call-frequency profile (bench/callfreq.lua)
-- showed these are called millions of times each, and -- crucially -- their
-- compiled-KL bodies re-dispatch through F["="]/F["cons?"]/F["hd"]/F["tl"] on
-- every iteration. The native bodies call the Lua `equal`/`is_cons`/`cons`
-- directly (no F-table round-trip), so overriding them also CASCADES down the
-- inner-primitive call counts (= at 39M, cons? at 34M, ...).
--
-- Semantics mirror klambda/sys.kl EXACTLY. For the list walkers, the rare
-- improper-list error branch DELEGATES to the captured original compiled-KL
-- function, so the (multi-line) simple-error messages stay byte-identical without
-- transcription. None of these touch shen.*infs* except shen.incinfs (which is
-- kept arithmetically identical), so the typecheck inference count is unchanged.
-- ---- native shen.lambda-entry (installed EARLY; see boot.lua) --------------
-- shen.lambda-entry (declarations.kl) :
--   (let A (arity Name)
--     (if (or (= A -1) (= A 0)) ()
--         (cons Name (eval-kl (shen.lambda-function (cons Name ()) A)))))
-- shen.lambda-function (reader.kl) builds the KL term
--   (lambda Y1 (lambda Y2 ... (Name Y1 ... Yn)))
-- and eval-kl then runs the WHOLE KL->Lua compiler plus loadstring on it — to
-- produce, verbatim,
--   MKFUN(1, function(a) return MKFUN(1, function(b) return F[Name](a,b) end) end)
-- i.e. a curried chain over a late-bound F lookup and nothing else. That is one
-- Lua chunk compiled per lambda table entry, and an entry is built for every
-- `define` (shen.update-lambdatable), for every name a fasl replay rebuilds
-- (~285 in a warm standard-library load) and for every external kernel symbol
-- at boot (~280, from declarations.kl's (shen.build-lambda-table (external
-- shen))). Build the chain directly instead.
--
-- The innermost call goes through APP on the name SYMBOL rather than calling
-- F[Name] directly, which is what the compiled form does for a name whose arity
-- is not known at codegen time: same late binding, and an arity that no longer
-- matches the property (a redefinition between entry build and call) curries or
-- over-applies exactly as APP always does instead of silently passing the wrong
-- argument count.
--
-- This one is deliberately NOT part of install_native_stdlib: that runs after
-- the whole kernel is loaded, which is far too late for the boot-time
-- build-lambda-table. It has no dependency on the compiled original — `arity`
-- returns an integer or -1 for every input, so every branch is reachable
-- natively — so boot.lua installs it the moment declarations.kl has defined
-- `arity` and the lambda table is about to be built.
local NATIVE_LAMBDA_ENTRY = false
local function curried(sym, need, got)
  return MKFUN(1, function(x)
    local n = #got
    local nxt = {}
    for i = 1, n do nxt[i] = got[i] end
    nxt[n + 1] = x
    if need == 1 then return APP(sym, unpack(nxt, 1, n + 1)) end
    return curried(sym, need - 1, nxt)
  end)
end
function P.install_native_lambda_entry()
  if NATIVE_LAMBDA_ENTRY then return end
  if type(F["arity"]) ~= "function" then return end
  local function lambda_entry(name)
    local ar = F["arity"](name)
    if type(ar) ~= "number" or ar <= 0 or ar ~= math.floor(ar) then return NIL end
    return cons(name, curried(name, ar, {}))
  end
  F["shen.lambda-entry"] = lambda_entry
  FA[lambda_entry] = 1
  NATIVE_LAMBDA_ENTRY = true
end

function P.install_native_stdlib()
  local fail_sym = intern("shen.fail!")

  -- fail / parse-failure: return the fail symbol.  parse-failure?: (= V (fail)),
  -- which for the interned singleton fail symbol is exactly an identity test.
  local function fail() return fail_sym end
  local function parse_failure() return fail_sym end
  local function parse_failure_q(v) return v == fail_sym end

  -- shen.unlocked?: (<-address V 1) == v[3] in the pure-array vector layout.
  local function unlocked_q(v) return v[3] end

  -- shen.incinfs: (set shen.*infs* (+ 1 (value shen.*infs*))). Kept
  -- arithmetically identical so the inference-count invariant (431741) holds.
  local function incinfs()
    local n = GLOBALS["shen.*infs*"] + 1
    GLOBALS["shen.*infs*"] = n
    return n
  end

  -- element? : linear membership using KL `=` (== Lua `equal`). Improper-list
  -- error delegates to the original for an identical message.
  local orig_element = F["element?"]
  local function element_q(x, lst)
    while true do
      if lst == NIL then return false end
      if is_cons(lst) then
        if equal(x, lst[1]) then return true end
        lst = lst[2]
      else
        return orig_element(x, lst)
      end
    end
  end

  -- assoc : find the first pair whose head `= X`.
  local orig_assoc = F["assoc"]
  local function assoc(x, lst)
    while true do
      if lst == NIL then return NIL end
      if is_cons(lst) then
        local pair = lst[1]
        if is_cons(pair) and equal(x, pair[1]) then return pair end
        lst = lst[2]
      else
        return orig_assoc(x, lst)
      end
    end
  end

  -- shen.assoc-> (reader.kl) : functional assoc-list update —
  --   (cond ((= () L) (cons (cons K V) ()))
  --         ((and (cons? L) (and (cons? (hd L)) (= K (hd (hd L)))))
  --                        (cons (cons (hd (hd L)) V) (tl L)))
  --         ((cons? L) (cons (hd L) (shen.assoc-> K V (tl L))))
  --         (true (simple-error "implementation error in shen.assoc->")))
  -- i.e. replace the matching entry in place (keeping the STORED key object,
  -- not the probe) or append a new one at the end, copying the prefix.
  -- Like `append` the KL is non-tail-recursive: one stack frame and one
  -- F-table lookup per entry scanned. It is the update primitive behind
  -- shen.*lambdatable* (every `define`, and every entry a fasl replay
  -- rebuilds), shen.*sigf* (every `declare`) and shen.*datatypes*, all of
  -- which are assoc lists several hundred entries long by the time the
  -- standard library is loaded — so a boot walks it O(n^2). Native: copy the
  -- prefix iteratively, splice the tail. Fresh cells are unshared until we
  -- return, so in-place tail assignment is unobservable; an improper list
  -- delegates to the original for the identical simple-error.
  local orig_assoc_to = F["shen.assoc->"]
  local function assoc_to(k, v, l)
    local orig = l
    local head, last
    while true do
      if l == NIL then
        local cell = cons(cons(k, v), NIL)
        if last then last[2] = cell; return head end
        return cell
      end
      if not is_cons(l) then return orig_assoc_to(k, v, orig) end
      local pair = l[1]
      if is_cons(pair) and equal(k, pair[1]) then
        local cell = cons(cons(pair[1], v), l[2])
        if last then last[2] = cell; return head end
        return cell
      end
      local cell = cons(pair, NIL)
      if last then last[2] = cell else head = cell end
      last = cell
      l = l[2]
    end
  end

  -- shen.reverse-help (and reverse, its only caller) : accumulate-reverse.
  local orig_revh = F["shen.reverse-help"]
  local function reverse_help(lst, acc)
    while true do
      if lst == NIL then return acc end
      if is_cons(lst) then
        acc = cons(lst[1], acc); lst = lst[2]
      else
        return orig_revh(lst, acc)
      end
    end
  end
  local function reverse(lst) return reverse_help(lst, NIL) end

  -- append (sys.kl):
  --   (cond ((= () A) B)
  --         ((cons? A) (cons (hd A) (append (tl A) B)))
  --         (true (simple-error "attempt to append a non-list")))
  -- The KL is NON-tail-recursive: every element of A is a stack frame that
  -- re-looks-up F["hd"]/F["tl"]/F["append"] and builds one cons on the way
  -- back. On urdr's software-SHA-256 suite (word.rotr concatenates 32-bit
  -- bit-lists via append) that is ~10% of leaf samples. Native: walk A once
  -- building a fresh spine iteratively (exactly |A| new cons cells — same
  -- allocation as the recursive form, no intermediate reverse list), then
  -- splice B onto the last cell. Fresh cells are not shared until we return,
  -- so in-place tail assignment is unobservable. Improper / non-list inputs
  -- delegate to the original so the simple-error message stays byte-identical.
  local orig_append = F["append"]
  local function append(a, b)
    if a == NIL then return b end
    if not is_cons(a) then return orig_append(a, b) end
    local orig = a
    local head = cons(a[1], NIL)
    local last = head
    a = a[2]
    while is_cons(a) do
      local cell = cons(a[1], NIL)
      last[2] = cell
      last = cell
      a = a[2]
    end
    if a ~= NIL then return orig_append(orig, b) end
    last[2] = b
    return head
  end

  -- shen.map-h (and map) : map a function over a list, building the result
  -- reversed then reversing (exactly as the KL does). The mapper is applied via
  -- APP (it may be a closure, a partial, or a symbol).
  local orig_maph = F["shen.map-h"]
  local function map_h(f, lst, acc)
    while true do
      if lst == NIL then return reverse_help(acc, NIL) end
      if is_cons(lst) then
        -- a counted call: a walker that recurses through map nests here
        local v
        local d = SD[1]
        if d < SEG_FRAMES then SD[1] = d + 1; v = APP(f, lst[1]); SD[1] = d
        else v = SEGRUN(APP, f, lst[1]) end
        acc = cons(v, acc); lst = lst[2]
      else
        return orig_maph(f, lst, acc)
      end
    end
  end
  local function map(f, lst) return map_h(f, lst, NIL) end

  -- variable? : a symbol whose name is an uppercase letter followed by
  -- alphanums (kernel chain variable?/analyse-variable?/uppercase?/alphanums?,
  -- where alphanum = letter | digit | the misc set "=-*/+_?$!@~.><&%'#`").
  -- The kernel version walks the name char-by-char through trap-error +
  -- hdstr/tlstr string churn; here one pattern match, memoized on the
  -- interned symbol itself so each distinct symbol pays it once. Non-symbols
  -- delegate to the original for byte-identical edge semantics.
  local orig_variable = F["variable?"]
  local VARPAT = "^[A-Z][%w=%-%*/%+_%?%$!@~%.><&%%'#`]*$"
  local function variable_q(x)
    if is_symbol(x) then
      local v = x.isvar
      if v == nil then
        v = string.find(x.name, VARPAT) ~= nil
        x.isvar = v
      end
      return v
    end
    return orig_variable(x)
  end

  -- pr (issue #22): the canonical kernel `pr` (klambda/writer.kl) gates ALL
  -- output on *hush*:
  --     (defun pr (S ST) (if (value *hush*) S (...write S to ST...)))
  -- That silences writes to ANY stream under -q/*hush*, so `pr` to a FILE
  -- stream produced a zero-byte file — a divergence from shen-cl/shen-go/
  -- ShenScript, which write to files regardless of *hush*. *hush* is meant to
  -- suppress only the interactive/echo output that goes to standard output.
  -- This native override consults *hush* ONLY when the target is the standard
  -- output stream (*stoutput*); writes to any other stream always occur. That
  -- is a deliberate policy: writes to FILE streams and to *sterror* (error /
  -- diagnostic output) are NOT silenced by *hush* — only standard-output
  -- chatter is. The actual write delegates to the original compiled-KL pr
  -- (with *hush* cleared) so the write path stays byte-identical.
  local orig_pr = F["pr"]
  local function pr(s, st)
    if GLOBALS["*hush*"] and st == GLOBALS["*stoutput*"] then return s end
    -- hush-load (issue #46 item 3): while a (load ...) is in progress and
    -- P.HUSH_LOAD_ECHO is on, boot.lua's load wrapper records the chunk
    -- nesting depth at load entry in P.LOADPR_DEPTH. A pr to standard output
    -- at exactly that depth is `load`'s own chatter — the per-form value/type
    -- echo (shen.eval-and-print / shen.work-through) and the "run time"/
    -- "typechecked in N inferences" banners, all emitted AFTER (outside) the
    -- form's eval-kl chunk — whereas user (output ...) runs INSIDE a chunk
    -- (depth+1) and is left alone. Same policy as *hush*: only standard
    -- output is gated; file streams and *sterror* always write.
    if P.LOADPR_DEPTH ~= nil and P.CHUNK_DEPTH == P.LOADPR_DEPTH
       and st == GLOBALS["*stoutput*"] then return s end
    if GLOBALS["*hush*"] then
      -- non-stdout stream under *hush*: write unconditionally. Temporarily
      -- clear *hush* so the original kernel pr takes its write branch, then
      -- restore it so we don't perturb global state.
      local saved = GLOBALS["*hush*"]
      GLOBALS["*hush*"] = false
      local ok, res = pcall(orig_pr, s, st)
      GLOBALS["*hush*"] = saved
      if not ok then error(res, 0) end
      return res
    end
    return orig_pr(s, st)
  end

  -- hash (sys.kl:117) drives EVERY dict operation — get/put and the whole
  -- property system (arities, source, types, ...). The kernel computes it as
  --   (shen.mod (shen.prodbutzero (map string->n (explode V)) 1) Bound)
  -- i.e. explode V into its printed characters, take each character's code
  -- (string->n: its Unicode code point, issue #80), and fold them with
  -- prodbutzero: multiply while the accumulator stays <= 1e10, switch to ADD
  -- once it exceeds (the kernel's own overflow guard — so the key never
  -- leaves the double-exact range), then reduce mod Bound with 0 mapped to 1.
  -- For a symbol explode yields the characters of its name; for a string,
  -- the characters of the string. ASCII text folds bytes directly (byte ==
  -- code point); text with a byte >= 0x80 folds code points, exactly as the
  -- kernel definition does over the code-point primitives, so the result
  -- agrees with the compiled-KL hash and with = (equal strings, equal hash).
  -- Any other value type delegates to the original so its exact printed form
  -- is never second-guessed. Boot alone calls hash ~800 times (all on symbol
  -- keys); a native fold there and at runtime avoids the per-call explode
  -- list + map + KL recursion.
  local orig_hash = F["hash"]
  local function hashkey_bytes(s)
    local acc = 1
    local len = #s
    for i = 1, len do
      local b = sbyte(s, i)
      if b >= 0x80 then acc = nil; break end
      if b ~= 0 then
        if acc > 10000000000 then acc = acc + b else acc = acc * b end
      end
    end
    if acc then return acc end
    do                                -- non-ASCII: fold code points
      acc = 1
      local i = 1
      while i <= len do
        local b, l = u8dec(s, i)
        if b ~= 0 then
          if acc > 10000000000 then acc = acc + b else acc = acc * b end
        end
        i = i + l
      end
      return acc
    end
  end
  local function hash(v, bound)
    local s
    if is_symbol(v) then s = v.name
    elseif type(v) == "string" then s = v
    else return orig_hash(v, bound) end
    local h = hashkey_bytes(s) % bound
    if h == 0 then return 1 end
    return h
  end

  -- fn (reader.kl): the 42 shen->kl translator compiles every call to a
  -- function whose arity is unknown at translation time (forward references
  -- within a file, mainly) as ((fn name) args...), and the kernel `fn` pays
  -- an arity property get PLUS a shen.lambda-form property get (a
  -- trap-error'd dict lookup on 42.2; an assoc over shen.*lambdatable* on S42)
  -- on EVERY such call — measured at ~35% of urdr's software-SHA-256 suite
  -- (jit.p F3: is_cons/equal < assoc < fn). Fast path: for a symbol naming
  -- a live function with known positive arity, verify the lambdatable entry
  -- ONCE per (name, lambdatable identity) through the original `fn` — so an
  -- unregistered name still raises the kernel's "fn: X is undefined" — and
  -- from then on return the RAW F[name] function instead of the table's
  -- curried lambda. APP dispatches a raw function with recorded arity
  -- identically to the curried chain (exact call, partial application,
  -- over-application), but without one MKFUN closure allocation per applied
  -- argument. Every write of a shen.lambda-form property (native put/unput,
  -- i.e. update-lambda-table / shen.set-lambda-form-entry) bumps
  -- P.LAMBDA_FORM_GEN, which is the invalidation key (the 42.0 requirement:
  -- a redefinition must drop the cached callable form); arity-0 and
  -- unknown-arity names always take the original path (kernel `fn` CALLS an
  -- arity-0 function rather than returning it).
  local orig_fn = F["fn"]
  local fn_seen, fn_seen_lt, fn_seen_lt2 = {}, nil, nil
  local function fn_fast(v)
    if is_symbol(v) then
      local f = F[v.name]
      local ar = f ~= nil and FA[f] or nil
      if ar and ar > 0 then
        -- (an S42-lineage kernel via SHEN_KL_DIR or a Yggdrasil slice keeps
        -- its lambda table in shen.*lambdatable*: a fresh spine per update)
        local lt, lt2 = P.LAMBDA_FORM_GEN, GLOBALS["shen.*lambdatable*"]
        if lt ~= fn_seen_lt or lt2 ~= fn_seen_lt2 then
          fn_seen = {}; fn_seen_lt = lt; fn_seen_lt2 = lt2
        end
        if fn_seen[v.name] then return f end
        orig_fn(v)               -- errors exactly like the kernel on a miss
        fn_seen[v.name] = true
        return f
      end
    end
    return orig_fn(v)
  end

  -- shen.<singleline> / shen.<multiline> (reader.kl): comment scanners.
  --
  -- The kernel KL recurses once per comment CHARACTER without a tail call
  -- (<shortnatters>/<returns> inside <singleline>, <longnatter> inside
  -- <multiline>), so a comment past ~7 KB overflows the Lua stack on LuaJIT
  -- (~65500 fixed slots; ports with growable stacks read the same input
  -- fine) -- and read-file's trap-error rebrands the overflow as
  -- "reader error near here:". These native scanners are iterative, so the
  -- readable comment size becomes memory-bound. Grammar, replicated exactly:
  --
  --   <singleline>  ::= \ \ <shortnatters> <returns>
  --   <shortnatters>::= {c | not return?(c)}*     (greedy, may be empty)
  --   <returns>     ::= {c | return?(c)}+         (greedy, at least one)
  --   return? c     ::= c in {9, 10, 13}
  --   <multiline>   ::= \ * <longnatter>
  --   <longnatter>  ::= <comment> <longnatter> | * \ | any-char <longnatter>
  --
  -- Success returns (shen.comb Rest shen.skip) = (cons Rest (cons skip ()));
  -- failure returns (fail), exactly as the KL. All input inspection is
  -- cons? + head equality, so improper or non-numeric "byte" lists take the
  -- same failure paths the KL takes.
  --
  -- SUBTLETY (backtracking): <longnatter>'s first alternative is
  -- (<comment> then RECURSE); if the comment parses but the CONTINUATION
  -- then fails, the KL falls through to the skip-one-char alternative at the
  -- ORIGINAL position -- e.g. in "\* a \* b *\ x" the inner "\*" is demoted
  -- to plain text and the outer comment closes at the single "*\". A linear
  -- scan with a nesting counter gets that wrong, so <longnatter> is computed
  -- as a right-to-left dynamic program over positions: L[i] = rest position
  -- after the matching close when scanning from i (or fail). Each L[i]
  -- depends only on L[j], j > i, so one backward pass reproduces the KL's
  -- ordered choice exactly, in O(n) space and near-linear time, with no
  -- recursion at all (comment NESTING costs zero stack here too).
  local skip_sym = intern("shen.skip")
  local function comb_skip(rest) return cons(rest, cons(skip_sym, NIL)) end
  local function is_ret(c) return c == 9 or c == 10 or c == 13 end

  -- consume `\ \ <shortnatters> <returns>` from v; the remaining list, or nil
  local function scan_singleline(v)
    if not (is_cons(v) and v[1] == 92) then return nil end
    v = v[2]
    if not (is_cons(v) and v[1] == 92) then return nil end
    v = v[2]
    while is_cons(v) and not is_ret(v[1]) do v = v[2] end   -- <shortnatters>
    if not (is_cons(v) and is_ret(v[1])) then return nil end -- <returns>: >= 1
    while is_cons(v) and is_ret(v[1]) do v = v[2] end
    return v
  end

  -- <longnatter> from v; the remaining list after the closing `*\`, or nil
  local function scan_longnatter(v)
    local cells = {}
    local n = 0
    while is_cons(v) do n = n + 1; cells[n] = v; v = v[2] end
    local term = v                    -- NIL, or an improper tail
    local L = {}                      -- position 1..n+1, or false = fail
    L[n + 1] = false                  -- out of input: every alternative fails
    -- end position of a <singleline> starting at array index i, or nil
    local function sl_end(i)
      if not (cells[i + 1] and cells[i + 1][1] == 92) then return nil end
      local j = i + 2
      while j <= n and not is_ret(cells[j][1]) do j = j + 1 end
      if j > n then return nil end
      while j <= n and is_ret(cells[j][1]) do j = j + 1 end
      return j
    end
    for i = n, 1, -1 do
      local res = false
      local b = cells[i][1]
      if b == 92 then
        local nx = cells[i + 1] and cells[i + 1][1]
        if nx == 92 then
          -- alt 1 as <comment>/<singleline>, then continue
          local j = sl_end(i)
          if j and L[j] then res = L[j] end
        elseif nx == 42 then
          -- alt 1 as <comment>/<multiline>: inner close, then continue
          local m = L[i + 2]
          if m and L[m] then res = L[m] end
        end
        if not res then res = L[i + 1] end  -- alt 3: plain character
      elseif b == 42 and cells[i + 1] and cells[i + 1][1] == 92 then
        res = i + 2                          -- alt 2: `* \` closes
      else
        res = L[i + 1]                       -- alt 3: plain character
      end
      L[i] = res
    end
    local r = L[1]
    if not r then return nil end
    if r == n + 1 then return term end
    return cells[r]
  end

  local function singleline_p(v)
    local rest = scan_singleline(v)
    if rest == nil then return fail_sym end
    return comb_skip(rest)
  end
  local function multiline_p(v)
    if not (is_cons(v) and v[1] == 92) then return fail_sym end
    local v2 = v[2]
    if not (is_cons(v2) and v2[1] == 42) then return fail_sym end
    local rest = scan_longnatter(v2[2])
    if rest == nil then return fail_sym end
    return comb_skip(rest)
  end

  -- shen.<s-exprs> (reader.kl): the reader's token-sequence rule.
  --
  -- Like the comment scanners above, the KL recurses once per TOKEN without
  -- a tail call (every alternative but <e> is `<token> <s-exprs>`), so a list
  -- literal past ~1550 elements overflowed the Lua stack and read-file's
  -- trap-error reported it as "reader error near here:" (issue #88). This
  -- version keeps the grammar's ordered choice but walks the input in a loop
  -- with an explicit stack of open brackets. The single-token rules (<atom>,
  -- <lsb>, <comment>, ...) are still the kernel's, called through F, so
  -- token syntax is untouched. Grammar, in the KL's order:
  --
  --   <s-exprs> ::= <lsb> <s-exprs1> <rsb> <s-exprs2>  -> [cons-form(S1) | S2]
  --               | <lrb> <s-exprs1> <rrb> <s-exprs2>  -> add-sexpr(S1, S2)
  --               | <lcurly> <s-exprs> | <rcurly> <s-exprs> | <bar> <s-exprs>
  --               | <semicolon> <s-exprs> | <colon> <equal> <s-exprs>
  --               | <colon> <s-exprs> | <comma> <s-exprs>   -> [Token | S]
  --               | <comment> <s-exprs> | <whitespaces> <s-exprs> -> S
  --               | <atom> <s-exprs>                        -> [Atom | S]
  --               | <e>                                     -> []
  --
  -- <s-exprs1>/<s-exprs2> are <s-exprs>, and <s-exprs> never fails (<e>), so
  -- once a token matches, its alternative succeeds -- except a bracket whose
  -- closer is missing. Then, as in the KL, the inner sequence has already
  -- been built and the remaining alternatives are tried at the bracket.
  -- Values are built in the KL's order: a sequence is folded right to left
  -- when it ends, so cons-form/add-sexpr (cons-form can raise "misapplication
  -- of |") run in the same order the KL's nested lets run them.
  local SX_LSB, SX_LRB = 1, 2   -- alternative numbers of the bracket rules
  local sx_tokens = {           -- alternatives 3.., after the bracket rules
    { "shen.<lcurly>", intern("{") },
    { "shen.<rcurly>", intern("}") },
    { "shen.<bar>", intern("bar!") },
    { "shen.<semicolon>", intern(";") },
    { "shen.<colon>", intern(":="), "shen.<equal>" },
    { "shen.<colon>", intern(":") },
    { "shen.<comma>", intern(",") },
    { "shen.<comment>" },
    { "shen.<atom>", true },
    { "shen.<whitespaces>" },
  }
  -- try the alternatives from number `from` on at v: returns the kind
  -- ("open", "item", "skip", or nil for <e>), the rest, and the value
  local function sx_step(v, from)
    if from <= SX_LSB then
      local r = F["shen.<lsb>"](v)
      if r ~= fail_sym then return "open", r[1], SX_LSB end
    end
    if from <= SX_LRB then
      local r = F["shen.<lrb>"](v)
      if r ~= fail_sym then return "open", r[1], SX_LRB end
    end
    for i = math.max(from - SX_LRB, 1), #sx_tokens do
      local t = sx_tokens[i]
      local r = F[t[1]](v)
      if r ~= fail_sym and t[3] then r = F[t[3]](r[1]) end
      if r ~= fail_sym then
        if t[2] == true then return "item", r[1], r[2][1] end
        if t[2] then return "item", r[1], t[2] end
        return "skip", r[1]
      end
    end
    return nil
  end
  local function s_exprs(v)
    -- frame: the items of one sequence; frame.alt/frame.pos record the
    -- bracket in the PARENT sequence that opened it
    local frame = { n = 0 }
    local stack, sp = {}, 0
    local from = 1
    while true do
      local kind, rest, val = sx_step(v, from)
      from = 1
      if kind == "open" then
        sp = sp + 1; stack[sp] = frame
        frame = { n = 0, alt = val, pos = v }
        v = rest
      elseif kind == "item" then
        frame.n = frame.n + 1; frame[frame.n] = { val }
        v = rest
      elseif kind == "skip" then
        v = rest
      else
        -- <e>: this sequence ends at v; fold it right to left
        local acc = NIL
        for i = frame.n, 1, -1 do
          local it = frame[i]
          if it.alt == SX_LSB then acc = cons(F["shen.cons-form"](it.inner), acc)
          elseif it.alt == SX_LRB then acc = F["shen.add-sexpr"](it.inner, acc)
          else acc = cons(it[1], acc) end
        end
        if sp == 0 then return cons(v, cons(acc, NIL)) end
        local closed = frame
        frame = stack[sp]; stack[sp] = nil; sp = sp - 1
        local r = F[closed.alt == SX_LSB and "shen.<rsb>" or "shen.<rrb>"](v)
        if r ~= fail_sym then
          frame.n = frame.n + 1
          frame[frame.n] = { alt = closed.alt, inner = acc }
          v = r[1]
        else
          -- no closer: the bracket alternative fails; try the next ones there
          v = closed.pos
          from = closed.alt + 1
        end
      end
    end
  end

  -- shen.<strcontents> / shen.<alphanums> (reader.kl): `<one> <self> | <e>`,
  -- joined with cn, so a string literal (or symbol) recursed once per
  -- character: a ~7 KB string such as (read-from-string "[1 2 ... 1600]")
  -- overflowed. Strings concatenate associatively, so one table.concat of
  -- the pieces is the KL's right-nested cn.
  local function cn_star(one)
    return function(v)
      local parts, n = {}, 0
      while true do
        local r = F[one](v)
        if r == fail_sym then break end
        n = n + 1; parts[n] = r[2][1]; v = r[1]
      end
      return cons(v, cons(table.concat(parts, "", 1, n), NIL))
    end
  end
  local strcontents = cn_star("shen.<strc>")
  local alphanums = cn_star("shen.<alphanum>")
  -- shen.<whitespaces>: <whitespace> <whitespaces> | <whitespace>
  local function whitespaces(v)
    local r = F["shen.<whitespace>"](v)
    if r == fail_sym then return fail_sym end
    repeat
      v = r[1]
      r = F["shen.<whitespace>"](v)
    until r == fail_sym
    return comb_skip(v)
  end

  -- shen.cons-form (reader.kl): [a b c] -> (cons a (cons b (cons c ()))),
  -- [a | b] -> (cons a b). The KL recurses once per element; this builds
  -- the same spine front to back. Anything the loop does not recognise is
  -- handed to the kernel's version, which raises its own error.
  local orig_cons_form = F["shen.cons-form"]
  local cons_sym, bar_sym = intern("cons"), intern("bar!")
  local function cons_form(x)
    local head, hole = nil, nil   -- hole: the cell whose head is still open
    while true do
      local node, nxt
      local t = is_cons(x) and x[2]
      if x == NIL then
        node = NIL
      elseif is_cons(t) and t[1] == bar_sym and is_cons(t[2]) then
        -- [a | b] ends the spine; [a | b c ...] is the kernel's error
        if t[2][2] ~= NIL then return orig_cons_form(x) end
        node = cons(cons_sym, cons(x[1], t[2]))
      elseif is_cons(x) then
        node = cons(cons_sym, cons(x[1], cons(NIL, NIL)))
        nxt = t
      else
        return orig_cons_form(x)
      end
      if hole then hole[1] = node else head = node end
      if nxt == nil then return head end
      hole = node[2][2]
      x = nxt
    end
  end

  -- ---- shen-scheme-style kernel overrides --------------------------------
  -- The kernel ships portable-but-slow defuns that overwrite the primitives
  -- of the same name (integer?, boolean?, empty?, not, thaw, symbol?, ...) and
  -- recursive-KL versions of list/string walkers (length, explode, nth, ...).
  -- shen-scheme's overrides.shen / unary-op-mapping is the same idea: replace
  -- those with a host mapping after the kernel loads. Error branches that have
  -- a distinctive simple-error message still delegate to the captured original.

  -- Kernel `(defun not (V) (if V false true))` — Lua truthiness, no boolean
  -- guard. The primitive `not` type-checks; restoring THAT would reject (not 1).
  local function native_not(x) return not x end
  local function boolean_q(x) return type(x) == "boolean" end
  local function empty_q(x) return x == NIL end
  local function integer_q(x)
    return type(x) == "number" and x == math.floor(x)
           and x ~= math.huge and x ~= -math.huge
  end
  local function thaw(x)
    if getmetatable(x) == Thunk then return runthunk(x) end
    if type(x) == "function" then return x() end
    return APP(x)
  end
  local function eqeq(a, b) return equal(a, b) end

  -- symbol? / analyse-symbol?: kernel walks str via trap-error + hdstr/tlstr.
  -- First char is alpha (letter or misc `=-*/+_?$!@~.><&%'#``); rest of those
  -- plus digits. `{` `}` `:` `;` `,` are special-cased true in symbol?.
  local orig_symbol = F["symbol?"]
  local orig_analyse_sym = F["shen.analyse-symbol?"]
  local SYMPAT = "^[=%-%*/%+_%?%$!@~%.><&%%'#`A-Za-z][=%-%*/%+_%?%$!@~%.><&%%'#`A-Za-z0-9]*$"
  local SPECIAL_SYM = { ["{"]=true, ["}"]=true, [":"]=true, [";"]=true, [","]=true }
  local function analyse_symbol_q(s)
    if type(s) ~= "string" or s == "" then return orig_analyse_sym(s) end
    return string.find(s, SYMPAT) ~= nil
  end
  local function symbol_q(x)
    if is_symbol(x) then
      local v = x.issym
      if v == nil then
        local n = x.name
        v = SPECIAL_SYM[n] or string.find(n, SYMPAT) ~= nil
        x.issym = v
      end
      return v
    end
    local t = type(x)
    if t == "boolean" or t == "number" or t == "string"
       or is_cons(x) or x == NIL then
      return false
    end
    return orig_symbol(x)
  end

  -- length: kernel length-h is (if empty then acc else (length-h (tl L) (+ acc 1)))
  -- so a non-list errors via `tl`. Delegate on an improper tail.
  local orig_length = F["length"]
  local orig_length_h = F["shen.length-h"]
  local function length(lst)
    local n, x = 0, lst
    while is_cons(x) do n = n + 1; x = x[2] end
    if x == NIL then return n end
    return orig_length(lst)
  end
  local function length_h(lst, acc)
    local n, x = acc, lst
    while is_cons(x) do n = n + 1; x = x[2] end
    if x == NIL then return n end
    return orig_length_h(lst, acc)
  end

  -- explode / string->bytes: kernel is per-character tlstr recursion.
  local orig_explode = F["explode"]
  local function explode(v)
    local s
    if type(v) == "string" then s = v
    elseif is_symbol(v) then s = v.name
    elseif type(v) == "boolean" then s = v and "true" or "false"
    elseif type(v) == "number" then s = numToStr(v)
    else return orig_explode(v) end
    return u8explode(s)
  end
  -- shen.string->bytes / shen.str->bytes: despite the names, the kernel
  -- builds both from string->n, i.e. character CODES (code points), which is
  -- also what the reader consumes (read-from-string = str->bytes + <s-exprs>).
  local orig_s2b = F["shen.string->bytes"]
  local function string_to_bytes(s)
    if type(s) ~= "string" then return orig_s2b(s) end
    return u8codes(s)
  end
  local orig_str2b = F["shen.str->bytes"]
  local function str_to_bytes(s)
    if type(s) ~= "string" then return orig_str2b(s) end
    return u8codes(s)
  end

  -- read-file: the kernel reads the file as a BYTE list and feeds it to the
  -- reader, whose <notdbq>/<alpha> rules rebuild text with n->string. With
  -- code-point strings that would re-encode every byte of a UTF-8 sequence
  -- as its own character (mojibake), so read-file instead decodes the file
  -- as UTF-8 into code points (lenient: an invalid byte reads as the code of
  -- that byte). read-file-as-bytelist itself keeps returning raw bytes. The
  -- body below is the kernel's read-file (reader.kl) over that code list.
  local orig_my_read_byte = F["shen.my-read-byte"]
  local function my_read_byte(st)
    if not is_stream(st) or st.kind ~= "in" then return orig_my_read_byte(st) end
    return stream_char(st)
  end
  local orig_read_file = F["read-file"]
  local function read_file(name)
    if type(name) ~= "string" then return orig_read_file(name) end
    local fh = io.open(home_path(name), "rb")
    if not fh then return orig_read_file(name) end   -- same open error
    local data = fh:read("*a") or ""
    fh:close()
    local codes = u8codes(data)
    local ok, parsed = pcall(F["compile"], F["shen.<s-exprs>"], codes)
    if not ok then
      -- a Lua stack overflow is not a syntax error: say so (issue #88)
      if type(parsed) == "string" and parsed:find("stack overflow", 1, true) then
        error(parsed, 0)
      end
      parsed = F["shen.reader-error"](GLOBALS["shen.*residue*"])
    end
    return F["shen.process-sexprs"](parsed)
  end

  -- concat: (intern (cn (str A) (str B))) — intern("true") is boolean true.
  local function concat(a, b)
    return F["intern"](F["str"](a) .. F["str"](b))
  end

  -- nth / sum / head / tail / hdstr / byte->digit / limit
  local orig_nth = F["nth"]
  local function nth(n, lst)
    if type(n) ~= "number" then return orig_nth(n, lst) end
    local i, x = n, lst
    while i > 1 and is_cons(x) do i = i - 1; x = x[2] end
    if i == 1 and is_cons(x) then return x[1] end
    return orig_nth(n, lst)
  end
  local orig_sum = F["sum"]
  local function sum(lst)
    local acc, x = 0, lst
    while is_cons(x) do
      local h = x[1]
      if type(h) ~= "number" then return orig_sum(lst) end
      acc = acc + h; x = x[2]
    end
    if x == NIL then return acc end
    return orig_sum(lst)
  end
  local orig_head = F["head"]
  local orig_tail = F["tail"]
  local function head(x)
    if is_cons(x) then return x[1] end
    return orig_head(x)
  end
  local function tail(x)
    if is_cons(x) then return x[2] end
    return orig_tail(x)
  end
  local orig_hdstr = F["hdstr"]
  local function hdstr(s)
    if type(s) ~= "string" or #s == 0 then return orig_hdstr(s) end
    return u8hd(s)
  end
  local function byte_to_digit(n) return n - 48 end
  local function limit(v) return v[2] end

  -- difference / union / intersection: kernel is non-tail recursive + element?.
  local orig_diff = F["difference"]
  local orig_union = F["union"]
  local orig_inter = F["intersection"]
  local function difference(a, b)
    local orig = a
    local acc, last
    while true do
      if a == NIL then
        if last then return acc else return NIL end
      end
      if not is_cons(a) then return orig_diff(orig, b) end
      if not element_q(a[1], b) then
        local cell = cons(a[1], NIL)
        if last then last[2] = cell else acc = cell end
        last = cell
      end
      a = a[2]
    end
  end
  local function union(a, b)
    local orig = a
    local acc, last
    local rest = b
    while true do
      if a == NIL then
        if last then last[2] = rest; return acc else return rest end
      end
      if not is_cons(a) then return orig_union(orig, b) end
      if not element_q(a[1], b) then
        local cell = cons(a[1], NIL)
        if last then last[2] = cell else acc = cell end
        last = cell
      end
      a = a[2]
    end
  end
  local function intersection(a, b)
    local orig = a
    local acc, last
    while true do
      if a == NIL then
        if last then return acc else return NIL end
      end
      if not is_cons(a) then return orig_inter(orig, b) end
      if element_q(a[1], b) then
        local cell = cons(a[1], NIL)
        if last then last[2] = cell else acc = cell end
        last = cell
      end
      a = a[2]
    end
  end

  -- occurrences / subst: tree walk. Lua recursion, same structure as the KL.
  local function occurrences(x, y)
    if equal(x, y) then return 1 end
    if is_cons(y) then return occurrences(x, y[1]) + occurrences(x, y[2]) end
    return 0
  end
  local function subst(n, o, tree)
    if equal(o, tree) then return n end
    if is_cons(tree) then return cons(subst(n, o, tree[1]), subst(n, o, tree[2])) end
    return tree
  end

  -- mapcan: (append (F (hd L)) (mapcan F (tl L)))
  local orig_mapcan = F["mapcan"]
  local function mapcan(f, lst)
    local orig = lst
    local head, last
    while true do
      if lst == NIL then
        if last then return head else return NIL end
      end
      if not is_cons(lst) then return orig_mapcan(f, orig) end
      local chunk
      local d = SD[1]   -- a counted call (see map_h)
      if d < SEG_FRAMES then SD[1] = d + 1; chunk = APP(f, lst[1]); SD[1] = d
      else chunk = SEGRUN(APP, f, lst[1]) end
      if chunk ~= NIL then
        -- append copies the left spine; copy each chunk so we don't mutate
        -- a list the mapper returned that might be shared. A non-list chunk
        -- is the kernel append error — raise it without re-running `f`.
        if not is_cons(chunk) then return orig_append(chunk, NIL) end
        local c = chunk
        while is_cons(c) do
          local cell = cons(c[1], NIL)
          if last then last[2] = cell else head = cell end
          last = cell
          c = c[2]
        end
        if c ~= NIL then return orig_mapcan(f, orig) end
      end
      lst = lst[2]
    end
  end

  -- @p / fst / snd / tuple?  (kernel: 3-slot absvector tagged shen.tuple)
  local tuple_tag = intern("shen.tuple")
  local function atp(x, y)
    return setmetatable({ [1] = 3, [2] = tuple_tag, [3] = x, [4] = y }, Vmt)
  end
  local function fst(v) return v[3] end
  local function snd(v) return v[4] end
  local function tuple_q(x)
    return getmetatable(x) == Vmt and x[2] == tuple_tag
  end

  -- vector: absvector(N+1), slot 0 = N, slots 1..N = fail. Kernel fillvector
  -- is one recursive address-> per slot.
  local orig_vector = F["vector"]
  local function vector(n)
    if type(n) ~= "number" or n < 0 or n ~= math.floor(n) then
      return orig_vector(n)
    end
    local v = { [1] = n + 1, [2] = n }
    for i = 1, n do v[i + 2] = fail_sym end
    return setmetatable(v, Vmt)
  end

  -- read-file-as-bytelist / read-file-as-string: kernel is per-byte read-byte
  -- + reverse / cn (quadratic). Same path semantics as the `open` primitive
  -- (relative to *home-directory*, see home_path).
  local orig_rfab = F["read-file-as-bytelist"]
  local orig_rfas = F["read-file-as-string"]
  local function read_file_as_bytelist(name)
    if type(name) ~= "string" then return orig_rfab(name) end
    local fh = io.open(home_path(name), "rb")
    if not fh then return orig_rfab(name) end
    local data = fh:read("*a") or ""
    fh:close()
    local acc = NIL
    for i = #data, 1, -1 do acc = cons(string.byte(data, i), acc) end
    return acc
  end
  local function read_file_as_string(name)
    if type(name) ~= "string" then return orig_rfas(name) end
    local fh = io.open(home_path(name), "rb")
    if not fh then return orig_rfas(name) end
    local data = fh:read("*a") or ""
    fh:close()
    return data
  end

  -- Property store (get/put/unput/arity) over the ShenOSKernel 42.2 dict
  -- (dict.kl). A dict is an absvector
  --   address 0: shen.dictionary   1: capacity   2: entry count
  --   address 3+i: bucket i  — an assoc list of (Key . Props)
  -- where Props is itself an assoc list of (Prop . Value). In the pure-array
  -- layout address a lives at v[a + 2]. The kernel's get/put/unput go through
  -- trap-error around shen.<-dict plus shen.assoc-set/shen.assoc-rm; these
  -- natives build exactly the same bucket and entry lists (assoc-set replaces
  -- in place keeping the stored key, else appends; assoc-rm drops the first
  -- match) without the pcall. Anything that is not a well-formed dict, and
  -- every error path, delegates to the compiled original so messages match.
  local orig_get = F["get"]
  local orig_put = F["put"]
  local orig_unput = F["unput"]
  local orig_arity = F["arity"]
  local arity_sym = intern("arity")
  local dict_sym = intern("shen.dictionary")
  local lambda_form_sym = intern("shen.lambda-form")
  -- bucket address of `key` in dict `vec`: returns bucket, slot index (v[]).
  local function bucket_at(vec, key)
    if getmetatable(vec) ~= Vmt or vec[2] ~= dict_sym then return nil, nil end
    local cap = vec[3]
    if type(cap) ~= "number" or cap <= 0 then return nil, nil end
    local h = hash(key, cap)
    if type(h) ~= "number" then return nil, nil end
    local slot = h + 5
    local b = vec[slot]
    if b == nil or b == fail_sym then return nil, nil end
    return b, slot
  end
  -- shen.assoc-set, iteratively; nil on an improper list (caller delegates).
  local function assoc_set(k, v, l)
    local head, last
    while true do
      if l == NIL then
        local cell = cons(cons(k, v), NIL)
        if last then last[2] = cell; return head, true end
        return cell, true
      end
      if not is_cons(l) then return nil end
      local pair = l[1]
      if is_cons(pair) and equal(k, pair[1]) then
        local cell = cons(cons(pair[1], v), l[2])
        if last then last[2] = cell; return head, false end
        return cell, false
      end
      local cell = cons(pair, NIL)
      if last then last[2] = cell else head = cell end
      last = cell
      l = l[2]
    end
  end
  -- shen.assoc-rm, iteratively; nil on an improper list.
  local function assoc_rm(k, l)
    local head, last
    while true do
      if l == NIL then
        if last then return head end
        return NIL
      end
      if not is_cons(l) then return nil end
      local pair = l[1]
      if is_cons(pair) and equal(k, pair[1]) then
        if last then last[2] = l[2]; return head end
        return l[2]
      end
      local cell = cons(pair, NIL)
      if last then last[2] = cell else head = cell end
      last = cell
      l = l[2]
    end
  end
  -- (key . props) entry of `key` in a bucket, or nil.
  local function find_entry(bucket, key)
    while is_cons(bucket) do
      local e = bucket[1]
      if is_cons(e) and equal(key, e[1]) then return e end
      bucket = bucket[2]
    end
    return nil
  end
  local function find_prop(props, prop)
    while is_cons(props) do
      local p = props[1]
      if is_cons(p) and equal(prop, p[1]) then return p end
      props = props[2]
    end
    return nil
  end
  -- Sidecar Lua table for *property-vector* (port-performance.md: property
  -- access). Kernel keys are almost always interned symbols, so identity
  -- table lookup beats hash+assoc. The dict remains the observable store;
  -- the cache is a write-through index.
  local PGET = {}
  local function cacheable(x)
    local t = type(x)
    return t == "string" or t == "number" or t == "boolean" or is_symbol(x)
  end
  local function cache_get(key, prop)
    if not (cacheable(key) and cacheable(prop)) then return nil, false end
    local t = PGET[key]
    if not t then return nil, false end
    local v = t[prop]
    if v == nil then return nil, false end
    return v, true
  end
  local function cache_put(key, prop, val)
    if not (cacheable(key) and cacheable(prop)) then return end
    local t = PGET[key]
    if not t then t = {}; PGET[key] = t end
    t[prop] = val
  end
  local function cache_rm(key, prop)
    local t = PGET[key]
    if t then t[prop] = nil end
  end
  local pv_of = function() return GLOBALS["*property-vector*"] end
  -- Bumped on every write of a shen.lambda-form property (update-lambda-table,
  -- shen.set-lambda-form-entry, unput): fn_fast's invalidation key. 42.0
  -- requires a cached callable form to be dropped when a function is
  -- redefined (in particular to zero or unknown arity).
  P.LAMBDA_FORM_GEN = 0
  local function lookup(key, prop, vec)
    local bucket = bucket_at(vec, key)
    if bucket == nil then return nil end
    local e = find_entry(bucket, key)
    if e == nil then return nil end
    local p = find_prop(e[2], prop)
    if p == nil then return nil end
    return p[2]
  end
  local function get(key, prop, vec)
    local is_pv = vec == pv_of()
    if is_pv then
      local v, ok = cache_get(key, prop)
      if ok then return v end
    end
    local val = lookup(key, prop, vec)
    if val == nil then return orig_get(key, prop, vec) end
    if is_pv then cache_put(key, prop, val) end
    return val
  end
  local function put(key, prop, val, vec)
    local bucket, slot = bucket_at(vec, key)
    if slot == nil then return orig_put(key, prop, val, vec) end
    local e = find_entry(bucket, key)
    local props, _ = assoc_set(prop, val, e and e[2] or NIL)
    if props == nil then return orig_put(key, prop, val, vec) end
    local nb, added = assoc_set(key, props, bucket)
    if nb == nil then return orig_put(key, prop, val, vec) end
    vec[slot] = nb
    if added then vec[4] = vec[4] + 1 end
    if vec == pv_of() then
      cache_put(key, prop, val)
      if prop == lambda_form_sym then P.LAMBDA_FORM_GEN = P.LAMBDA_FORM_GEN + 1 end
    end
    return val
  end
  local function unput(key, prop, vec)
    local bucket, slot = bucket_at(vec, key)
    if slot == nil then return orig_unput(key, prop, vec) end
    local e = find_entry(bucket, key)
    local props = assoc_rm(prop, e and e[2] or NIL)
    if props == nil then return orig_unput(key, prop, vec) end
    local nb, added = assoc_set(key, props, bucket)
    if nb == nil then return orig_unput(key, prop, vec) end
    vec[slot] = nb
    if added then vec[4] = vec[4] + 1 end
    if vec == pv_of() then
      cache_rm(key, prop)
      if prop == lambda_form_sym then P.LAMBDA_FORM_GEN = P.LAMBDA_FORM_GEN + 1 end
    end
    return key
  end
  local function arity(name)
    local v, ok = cache_get(name, arity_sym)
    if ok then return v end
    local pv = pv_of()
    if pv == nil then return -1 end
    if bucket_at(pv, name) == nil then return orig_arity(name) end
    local val = lookup(name, arity_sym, pv)
    if val == nil then return -1 end
    cache_put(name, arity_sym, val)
    return val
  end
  local function get_or(key, prop, vec, default)
    local is_pv = vec == pv_of()
    if is_pv then
      local v, ok = cache_get(key, prop)
      if ok then return v end
    end
    local val
    if bucket_at(vec, key) == nil then
      local ok, v = pcall(orig_get, key, prop, vec)
      if ok then val = v end
    else
      val = lookup(key, prop, vec)
    end
    if val == nil then
      if type(default) == "function" then return default() end
      return default
    end
    if is_pv then cache_put(key, prop, val) end
    return val
  end
  P.ENV.GET_OR = get_or

  -- vector? / <-vector / vector->  (trap-error around >= / fail-slot)
  local orig_vref = F["<-vector"]
  local orig_vset = F["vector->"]
  local function vector_q(x)
    if getmetatable(x) ~= Vmt then return false end
    local n = x[2]
    return type(n) == "number" and n >= 0
  end
  local function vref(v, i)
    if type(i) ~= "number" or i == 0 then return orig_vref(v, i) end
    local w = v[i + 2]
    if w == nil or w == fail_sym then return orig_vref(v, i) end
    return w
  end
  local function vset(v, i, x)
    if type(i) ~= "number" or i == 0 then return orig_vset(v, i, x) end
    v[i + 2] = x
    return v
  end

  -- gensym / @s / bound? / +string? / byte class predicates (reader)
  local function gensym(x)
    local n = (GLOBALS["shen.*gensym*"] or 0) + 1
    GLOBALS["shen.*gensym*"] = n
    return F["intern"](F["str"](x) .. numToStr(n))
  end
  local native_cn = F["cn"]
  local function ats(a, b) return native_cn(a, b) end
  local function bound_q(x)
    if not symbol_q(x) then return false end
    return GLOBALS[x.name] ~= nil
  end
  local orig_s2sym = F["string->symbol"]
  local function string_to_symbol(s)
    if type(s) ~= "string" then return orig_s2sym(s) end
    local w = F["intern"](s)
    if is_symbol(w) then return w end
    return orig_s2sym(s)
  end
  local function plus_string_q(s) return type(s) == "string" and #s > 0 end
  local function digit_q(n) return type(n) == "number" and n >= 48 and n <= 57 end
  local function uppercase_q(n) return type(n) == "number" and n >= 65 and n <= 90 end
  local function lowercase_q(n) return type(n) == "number" and n >= 97 and n <= 122 end
  local MISC = {
    [61]=true,[45]=true,[42]=true,[47]=true,[43]=true,[95]=true,[63]=true,
    [36]=true,[33]=true,[64]=true,[126]=true,[46]=true,[62]=true,[60]=true,
    [38]=true,[37]=true,[39]=true,[35]=true,[96]=true,
  }
  local function misc_q(n) return MISC[n] == true end
  local function alpha_q(n)
    return uppercase_q(n) or lowercase_q(n) or misc_q(n)
  end
  local orig_proc_nl = F["shen.proc-nl"]
  local function proc_nl(s)
    if type(s) ~= "string" then return orig_proc_nl(s) end
    return (s:gsub("~%%", "\n"))
  end

  -- Compile-path: define/yacc parser + free-var analysis (port-performance.md
  -- "source processing"). Called once per token / per define, not at runtime.
  local orig_analyse_var = F["shen.analyse-variable?"]
  local orig_alphanums = F["shen.alphanums?"]
  local function analyse_variable_q(s)
    if type(s) ~= "string" or s == "" then return orig_analyse_var(s) end
    return string.find(s, VARPAT) ~= nil
  end
  local function alphanums_q(s)
    if type(s) ~= "string" then return orig_alphanums(s) end
    if s == "" then return true end
    return string.find(s, "^[A-Za-z0-9=%-%*/%+_%?%$!@~%.><&%%'#`]*$") ~= nil
  end
  local orig_in = F["shen.in->"]
  local orig_out = F["shen.<-out"]
  local function hds_eq(v, x) return is_cons(v) and equal(v[1], x) end
  local function comb(a, b) return cons(a, cons(b, NIL)) end
  local function in_to(v)
    if is_cons(v) then return v[1] end
    return orig_in(v)
  end
  local function out_of(v)
    if is_cons(v) and is_cons(v[2]) then return v[2][1] end
    return orig_out(v)
  end
  local function ccons_q(v)
    if not is_cons(v) then return false end
    local h = v[1]
    return is_cons(h) or h == NIL
  end
  local orig_params = F["shen.parameters"]
  local v_sym = intern("V")
  local function parameters(n)
    if type(n) ~= "number" or n < 0 or n ~= math.floor(n) then
      return orig_params(n)
    end
    local cells = {}
    for i = 1, n do cells[i] = gensym(v_sym) end
    local acc = NIL
    for i = n, 1, -1 do acc = cons(cells[i], acc) end
    return acc
  end
  local function extract_vars(x)
    if variable_q(x) then return cons(x, NIL) end
    if is_cons(x) then return union(extract_vars(x[1]), extract_vars(x[2])) end
    return NIL
  end
  local protect_sym, let_sym, lambda_sym = intern("protect"), intern("let"), intern("lambda")
  local function find_free_vars(bound, form)
    if is_cons(form) then
      local h, t = form[1], form[2]
      if h == protect_sym and is_cons(t) and t[2] == NIL then return NIL end
      if h == let_sym and is_cons(t) then
        local x, t2 = t[1], t[2]
        if is_cons(t2) then
          local val, t3 = t2[1], t2[2]
          if is_cons(t3) and t3[2] == NIL then
            local body = t3[1]
            return union(find_free_vars(bound, val),
                         find_free_vars(cons(x, bound), body))
          end
        end
      end
      if h == lambda_sym and is_cons(t) then
        local x, t2 = t[1], t[2]
        if is_cons(t2) and t2[2] == NIL then
          return find_free_vars(cons(x, bound), t2[1])
        end
      end
      return union(find_free_vars(bound, h), find_free_vars(bound, t))
    end
    if variable_q(form) and not element_q(form, bound) then return cons(form, NIL) end
    return NIL
  end
  local function unprotect(x)
    if tuple_q(x) then return atp(unprotect(fst(x)), unprotect(snd(x))) end
    if is_cons(x) and x[1] == protect_sym and is_cons(x[2]) and x[2][2] == NIL then
      return unprotect(x[2][1])
    end
    if is_cons(x) then return map(unprotect, x) end
    return x
  end
  local orig_repx = F["shen.rep-X"]
  local function rep_X(old, new, tree)
    if equal(old, tree) then return new end
    if is_cons(tree) then
      local w = rep_X(old, new, tree[1])
      if equal(w, tree[1]) then return cons(tree[1], rep_X(old, new, tree[2])) end
      return cons(w, tree[2])
    end
    return tree
  end

  local function install(name, fn, arity) F[name] = fn; FA[fn] = arity end
  install("shen.<singleline>", singleline_p, 1)
  install("shen.<multiline>", multiline_p, 1)
  install("shen.<s-exprs>", s_exprs, 1)
  install("shen.cons-form", cons_form, 1)
  install("shen.<strcontents>", strcontents, 1)
  install("shen.<alphanums>", alphanums, 1)
  install("shen.<whitespaces>", whitespaces, 1)
  install("fn", fn_fast, 1)
  install("hash", hash, 2)
  install("pr", pr, 2)
  install("variable?", variable_q, 1)
  install("fail", fail, 0)
  install("shen.parse-failure", parse_failure, 0)
  install("shen.parse-failure?", parse_failure_q, 1)
  install("shen.unlocked?", unlocked_q, 1)
  install("shen.incinfs", incinfs, 0)
  install("element?", element_q, 2)
  install("assoc", assoc, 2)
  install("shen.assoc->", assoc_to, 3)
  install("append", append, 2)
  install("shen.reverse-help", reverse_help, 2)
  install("reverse", reverse, 1)
  install("shen.map-h", map_h, 3)
  install("map", map, 2)
  install("not", native_not, 1)
  install("boolean?", boolean_q, 1)
  install("empty?", empty_q, 1)
  install("integer?", integer_q, 1)
  install("thaw", thaw, 1)
  install("==", eqeq, 2)
  install("symbol?", symbol_q, 1)
  install("shen.analyse-symbol?", analyse_symbol_q, 1)
  install("length", length, 1)
  install("shen.length-h", length_h, 2)
  install("explode", explode, 1)
  install("shen.string->bytes", string_to_bytes, 1)
  install("shen.str->bytes", str_to_bytes, 1)
  install("read-file", read_file, 1)
  install("shen.my-read-byte", my_read_byte, 1)
  install("concat", concat, 2)
  install("nth", nth, 2)
  install("sum", sum, 1)
  install("head", head, 1)
  install("tail", tail, 1)
  install("hdstr", hdstr, 1)
  install("shen.byte->digit", byte_to_digit, 1)
  install("limit", limit, 1)
  install("difference", difference, 2)
  install("union", union, 2)
  install("intersection", intersection, 2)
  install("occurrences", occurrences, 2)
  install("subst", subst, 3)
  install("mapcan", mapcan, 2)
  install("@p", atp, 2)
  install("fst", fst, 1)
  install("snd", snd, 1)
  install("tuple?", tuple_q, 1)
  install("vector", vector, 1)
  install("read-file-as-bytelist", read_file_as_bytelist, 1)
  install("read-file-as-string", read_file_as_string, 1)
  install("get", get, 3)
  install("put", put, 4)
  install("unput", unput, 3)
  install("arity", arity, 1)
  install("vector?", vector_q, 1)
  install("<-vector", vref, 2)
  install("vector->", vset, 3)
  install("gensym", gensym, 1)
  install("@s", ats, 2)
  install("bound?", bound_q, 1)
  install("string->symbol", string_to_symbol, 1)
  install("shen.+string?", plus_string_q, 1)
  install("shen.digit?", digit_q, 1)
  install("shen.uppercase?", uppercase_q, 1)
  install("shen.lowercase?", lowercase_q, 1)
  install("shen.misc?", misc_q, 1)
  install("shen.alpha?", alpha_q, 1)
  install("shen.proc-nl", proc_nl, 1)
  install("shen.analyse-variable?", analyse_variable_q, 1)
  install("shen.alphanums?", alphanums_q, 1)
  install("shen.hds=?", hds_eq, 2)
  install("shen.comb", comb, 2)
  install("shen.in->", in_to, 1)
  install("shen.<-out", out_of, 1)
  install("shen.ccons?", ccons_q, 1)
  install("shen.parameters", parameters, 1)
  install("shen.extract-vars", extract_vars, 1)
  install("shen.find-free-vars", find_free_vars, 2)
  install("shen.unprotect", unprotect, 1)
  install("shen.rep-X", rep_X, 3)
  P.install_native_lambda_entry()   -- no-op if boot.lua already did it

  -- shen.x host SHA-256 (OpenSSL libcrypto). See pyrex41/shen-extensions.
  -- Disable with SHEN_X_SHA256=pure.
  if os.getenv("SHEN_X_SHA256") ~= "pure" then
    local ok_ffi, ffi = pcall(require, "ffi")
    if ok_ffi then
      local function load_crypto()
        local candidates = {}
        local function add(name)
          if name and name ~= "" then candidates[#candidates+1] = name end
        end
        add(os.getenv("SHEN_X_LIBCRYPTO"))
        if ffi.os == "OSX" then
          -- NEVER dlopen a bare "crypto"/"libcrypto" on macOS: depending on
          -- the luajit's dyld search paths it can resolve to Apple's
          -- /usr/lib/libcrypto.dylib STUB, which abort()s the whole process
          -- on load ("loading libcrypto in an unsafe way") — pcall cannot
          -- catch it. Absolute paths to a real OpenSSL only; a miss just
          -- means the pure oracle is used.
          local home = os.getenv("HOME") or ""
          add("/opt/homebrew/opt/openssl@3/lib/libcrypto.dylib")
          add("/usr/local/opt/openssl@3/lib/libcrypto.dylib")
          add(home .. "/.local/Homebrew/opt/openssl@3/lib/libcrypto.dylib")
        else
          add("crypto"); add("libcrypto")
          add("libcrypto.so.3"); add("libcrypto.so.1.1"); add("libcrypto.so")
        end
        for _, name in ipairs(candidates) do
          local ok, lib = pcall(ffi.load, name)
          if ok then return lib end
        end
        return nil
      end
      local crypto = load_crypto()
      if crypto then
        pcall(function()
          ffi.cdef[[
            unsigned char *SHA256(const unsigned char *d, size_t n, unsigned char *md);
          ]]
        end)
        local function sha256_octets_host(lst)
          local buf = {}
          local cur = lst
          while cur ~= NIL do
            if not is_cons(cur) then
              ERR("shen.x.sha256-octets-host: expected list of bytes 0..255")
            end
            local b = cur[1]
            if type(b) ~= "number" or b < 0 or b > 255 or b ~= math.floor(b) then
              ERR("shen.x.sha256-octets-host: expected list of bytes 0..255")
            end
            buf[#buf+1] = string.char(b)
            cur = cur[2]
          end
          local data = table.concat(buf)
          local md = ffi.new("unsigned char[32]")
          crypto.SHA256(data, #data, md)
          local acc = NIL
          for i = 31, 0, -1 do
            acc = cons(tonumber(md[i]), acc)
          end
          return acc
        end
        install("shen.x.sha256-octets-host", sha256_octets_host, 1)
        GLOBALS["shen.x.*sha256-backend*"] = intern("host")
      end
    end
  end
end

-- The reviewed macros.kl walk is a postorder map followed by APP. Its common
-- syntax-tree path needs neither a mapper closure nor a reversed list spine.
-- boot.lua qualifies the source before calling this installer.
function P.install_native_walk()
  local original, map, maph = F["shen.walk"], F["map"], F["shen.map-h"]
  local function walk(f, form)
    if F["map"] ~= map then return original(f, form) end
    if not is_cons(form) then return APP(f, form) end
    local head, last, tail = NIL, nil, form
    while is_cons(tail) do
      local v, d = nil, SD[1]
      local child_walk = F["shen.walk"]
      if d < SEG_FRAMES then SD[1] = d + 1; v = child_walk(f, tail[1]); SD[1] = d
      else v = SEGRUN(child_walk, f, tail[1]) end
      local cell = cons(v, NIL)
      if last then last[2] = cell else head = cell end
      last = cell
      tail = tail[2]
    end
    if tail ~= NIL then
      -- Continue the original map-h error path without replaying callbacks.
      local acc, cur = NIL, head
      while cur ~= NIL do acc = cons(cur[1], acc); cur = cur[2] end
      local mapper = function(child) return F["shen.walk"](f, child) end
      FA[mapper] = 1
      return APP(f, maph(mapper, tail, acc))
    end
    return APP(f, head)
  end
  F["shen.walk"], FA[walk] = walk, 2
end

-- ---- loader / eval -------------------------------------------------------
-- environment table exposed to compiled chunks
local ENV = {
  F = F, FA = FA, S = intern, NIL = NIL,
  APP = APP, PARTIAL = PARTIAL, MKFUN = MKFUN,
  ERR = ERR, TOEXCN = TOEXCN,
  KDATA = C.KDATA,
  MKLIST = function(arr, tail)
    local acc = tail
    for i=#arr,1,-1 do acc = cons(arr[i], acc) end
    return acc
  end,
  -- BIND wraps a per-defun continuation function `fn` together with a snapshot
  -- of its captures into a 0-arity thunk. The compiler hoists deep
  -- (freeze ...) bodies out to a KB table (see CTX in compiler.lua) and emits
  -- BIND(KB[i], cap1, ..., capN) at every use site, so the use site itself
  -- contains no Lua function literal -- avoiding chunk syntax-level overflow
  -- on Prolog CPS chains (einsteins-riddle, t-star).
  -- All thunks produced here are 0-arity and are invoked via `thaw` (direct
  -- call) or APP-with-0-args (whose fallback treats an unknown-arity function
  -- as exact-arity), so we no longer tag them in FA -- skipping a weak-table
  -- write on every freeze, one of the hottest ops in the typechecker.
  BIND = function(fn, ...)
    if select("#", ...) == 0 then return fn end
    if APROF then
      local nslots = select("#", ...) + 1
      AP.mkbind = AP.mkbind + 1; AP.mkbind_slots = AP.mkbind_slots + nslots
      AP_SLOTS[nslots] = (AP_SLOTS[nslots] or 0) + 1
    end
    return setmetatable({ fn, ... }, Thunk)
  end,
  -- A wide-mode lambda (compiler.lua, WIDE): its body is the constant
  -- function fn(x, T) with the captures in the table T.
  UNPACK = unpack,
  LAMW = function(fn, t)
    return MKFUN(1, function(x) return fn(x, t) end)
  end,
  -- A curried lambda chain n deep (compiler.lua, CURRY_DEPTH): each
  -- application returns a fresh closure over its own copy of the arguments
  -- so far, exactly like the nested closures; the last calls fn(args).
  CURRY = function(n, fn)
    local function step(args, i)
      return MKFUN(1, function(x)
        local a = { unpack(args, 1, i - 1) }
        a[i] = x
        if i == n then return fn(a) end
        return step(a, i + 1)
      end)
    end
    return step({}, 1)
  end,
  -- MKTREE consumes a flat blueprint produced by the compiler for deep
  -- cons-trees. See compile_cons_tree in compiler.lua. ops is a sequence of
  -- 'v' followed by a leaf value (push), or 'c' (pop two, push cons).
  MKTREE = function(ops)
    local stack, sp = {}, 0
    local i, n = 1, #ops
    while i <= n do
      local tag = ops[i]
      if tag == "v" then
        sp = sp + 1
        stack[sp] = ops[i+1]
        i = i + 2
      else
        local r = stack[sp]
        local l = stack[sp-1]
        sp = sp - 1
        stack[sp] = cons(l, r)
        i = i + 1
      end
    end
    return stack[1]
  end,
  -- Arithmetic / equality fast-paths (Track 1.1/1.2). The compiler emits these
  -- (ADD/SUB/.../EQ) instead of F["+"]/.../F["="] for 2-arg numeric-prim calls.
  -- Each takes the monomorphic-number fast path -- which LuaJIT folds to a bare
  -- machine op on a hot trace -- and otherwise falls back to the real primitive,
  -- which preserves KL semantics EXACTLY: tonum rejects non-numbers (so "3"+1
  -- still errors rather than string-coercing), and a user redefinition of `+`
  -- via F still takes effect. EQ on a numeric LHS is `a==b` (Lua never coerces
  -- across number/non-number in ==, matching `equal`); otherwise full `equal`.
  ADD = function(a,b) if type(a)=="number" and type(b)=="number" then return a+b end return F["+"](a,b) end,
  SUB = function(a,b) if type(a)=="number" and type(b)=="number" then return a-b end return F["-"](a,b) end,
  MUL = function(a,b) if type(a)=="number" and type(b)=="number" then return a*b end return F["*"](a,b) end,
  DIV = function(a,b) if type(a)=="number" and type(b)=="number" and b~=0 then return a/b end return F["/"](a,b) end,
  GT  = function(a,b) if type(a)=="number" and type(b)=="number" then return a>b  end return F[">"](a,b) end,
  LT  = function(a,b) if type(a)=="number" and type(b)=="number" then return a<b  end return F["<"](a,b) end,
  GE  = function(a,b) if type(a)=="number" and type(b)=="number" then return a>=b end return F[">="](a,b) end,
  LE  = function(a,b) if type(a)=="number" and type(b)=="number" then return a<=b end return F["<="](a,b) end,
  EQ  = function(a,b) if type(a)=="number" then return a==b end return equal(a,b) end,
  -- CALL0..CALLn are generated below the table (see unknown_call in compiler.lua).
  -- TRMC step markers (see TRMC in compiler.lua): never Shen values.
  TRMC_C = setmetatable({}, { __tostring = function() return "#<trmc cons>" end }),
  TRMC_T = setmetatable({}, { __tostring = function() return "#<trmc tail>" end }),
  -- CMT: the runtime Cons metatable, for the compiler's inlined exact-arity
  -- (cons A B) codegen — `setmetatable({A, B}, CMT)` (see ccall in
  -- compiler.lua). Keeps the hottest allocation out of the tiny F["cons"]
  -- wrapper proto, which LuaJIT otherwise blacklists under cons-heavy loads.
  CMT = R.Cons,
  -- Unary helpers for compiler inlining (see ccall in compiler.lua).
  -- HD/TL keep the primitive error path; THAW keeps the thunk / function /
  -- APP dispatch of the thaw primitive (which the kernel otherwise overwrites
  -- with `(defun thaw (V) (V))`).
  HD = function(x) if is_cons(x) then return x[1] end return F["hd"](x) end,
  TL = function(x) if is_cons(x) then return x[2] end return F["tl"](x) end,
  -- Yacc/define parser combinators (compile path).
  HDS_EQ = function(v, x) return is_cons(v) and equal(v[1], x) end,
  COMB = function(a, b)
    return setmetatable({ a, setmetatable({ b, NIL }, R.Cons) }, R.Cons)
  end,
  CCONS_Q = function(v)
    if not is_cons(v) then return false end
    local h = v[1]
    return is_cons(h) or h == NIL
  end,
  THAW = function(x)
    if getmetatable(x) == Thunk then return runthunk(x) end
    if type(x) == "function" then return x() end
    return APP(x)
  end,
  -- Direct GLOBALS access (compiler value/set of literal symbols, and the
  -- trap-error peephole). `false` is a valid stored value; only nil is unbound.
  G = GLOBALS,
  VALUE_S = function(key)
    local v = GLOBALS[key]
    if v ~= nil then return v end
    return F["value"](intern(key))
  end,
  SET_S = function(key, v) GLOBALS[key] = v; return v end,
  VALUE_OR_S = function(key, default)
    local v = GLOBALS[key]
    if v ~= nil then return v end
    if type(default) == "function" then return default() end
    return default
  end,
  VALUE_OR = function(sym, default)
    local key = is_symbol(sym) and sym.name or tostring(sym)
    local v = GLOBALS[key]
    if v ~= nil then return v end
    if type(default) == "function" then return default() end
    return default
  end,
  VEC_OR = function(v, n, default)
    if type(n) ~= "number" or n == 0 or type(v) ~= "table" then
      if type(default) == "function" then return default() end
      return default
    end
    local w = v[n + 2]
    if w == nil or w == FAILOBJ then
      if type(default) == "function" then return default() end
      return default
    end
    return w
  end,
  ADDR_OR = function(v, n, default)
    local w = (type(v) == "table" and type(n) == "number") and v[n + 2] or nil
    if w == nil then
      if type(default) == "function" then return default() end
      return default
    end
    return w
  end,
  -- Placeholder: trap-error (get ...) during kernel load, before native get.
  -- install_native_stdlib replaces this with a pcall-free lookup.
  GET_OR = function(key, prop, vec, default)
    local ok, v = pcall(F["get"], key, prop, vec)
    if ok then return v end
    if type(default) == "function" then return default() end
    return default
  end,
  CN = function(a, b)
    if type(a) == "string" and type(b) == "string" then return a .. b end
    return F["cn"](a, b)
  end,
  -- Inline string helpers (compiler.lua lowers pos/tlstr/string->n/n->string/
  -- hdstr to these). Fast path: the bytes involved are ASCII (< 0x80, or
  -- < 0xC2 for a lone first byte, which can never start a multi-byte
  -- character), so one byte is one character. Otherwise fall back to the
  -- code-point primitive (issue #80).
  POS = function(s, n)
    if type(s) == "string" and type(n) == "number" and n >= 0 and n < #s then
      if n == 0 then
        if sbyte(s, 1) < 0xC2 then return ssub(s, 1, 1) end
      else
        local h = first_high(s)           -- first non-ASCII byte, if any
        if not h or h > n + 1 then return ssub(s, n + 1, n + 1) end
      end
    end
    return F["pos"](s, n)
  end,
  TLSTR = function(s)
    if type(s) == "string" then
      local c = sbyte(s, 1)
      if c and c < 0xC2 then return ssub(s, 2) end
    end
    return F["tlstr"](s)
  end,
  STRN = function(s)
    if type(s) == "string" then
      local c = sbyte(s, 1)
      if c and c < 0xC2 then return c end
    end
    return F["string->n"](s)
  end,
  -- (string->n (pos S N)) fused by compiler.lua: the code of the N-th
  -- character without allocating the one-character string.
  STRNPOS = function(s, n)
    if type(s) == "string" and type(n) == "number" and n >= 0 and n < #s then
      local c = sbyte(s, n + 1)
      if n == 0 then
        if c < 0xC2 then return c end
      elseif c < 0x80 then
        local h = first_high(s)
        if not h or h > n + 1 then return c end
      end
    end
    return F["string->n"](F["pos"](s, n))
  end,
  NSTR = function(n)
    if type(n) == "number" and n >= 0 and n < 128 and n == mfloor(n) then
      return schar(n)
    end
    return F["n->string"](n)
  end,
  ADDR = function(v, i)
    local w = v[i + 2]
    if w == nil then return F["<-address"](v, i) end
    return w
  end,
  ADSET = function(v, i, x) v[i + 2] = x; return v end,
  VMT = Vmt,
  -- allow compiled code to reach a few Lua builtins safely
  -- trap-error's pcall restores the stack-segment count (runtime.lua, #93)
  pcall = R.seg.pcall, select = select, error = error,
  setmetatable = setmetatable, getmetatable = getmetatable,
  type = type,
  math = math, string = string, table = table,
}
P.ENV = ENV

-- counted non-tail calls (runtime.lua stack segments, #93): the count slot,
-- the segment runner and the trampoline for code outside a defun
ENV.SD, ENV.SEG, ENV.SEGSELF, ENV.NTV = R.seg.SD, R.seg.run, R.seg.runself, R.seg.NTV
R.seg.set_error(ERR)

-- CALL0..CALLn: late-bound fixed-arity calls to a function NAMED at compile
-- time whose arity was not yet known (forward references; see unknown_call
-- in compiler.lua). Generated from one template so each is a plain
-- fixed-parameter function LuaJIT can trace. Dispatch matches APP exactly:
-- a function with recorded arity n, or none recorded, is called directly;
-- anything else (partial / over-application, a missing or non-function
-- entry) takes the old APP(S(name), ...) path.
do
  for n = 0, C.MAX_CALLN do
    local ps = {}
    for i = 1, n do ps[i] = "a" .. i end
    local plist = table.concat(ps, ", ")
    local comma = n > 0 and ", " or ""
    local src = "local F, FA, APP, S = ...\n"
      .. "return function(name" .. comma .. plist .. ")\n"
      .. "  local f = F[name]\n"
      .. "  if type(f) == 'function' then\n"
      .. "    local ar = FA[f]\n"
      .. "    if ar == " .. n .. " or ar == nil then return f(" .. plist .. ") end\n"
      .. "  end\n"
      .. "  return APP(S(name)" .. comma .. plist .. ")\n"
      .. "end\n"
    ENV["CALL" .. n] = assert((loadstring or load)(src, "=CALL" .. n))(F, FA, APP, intern)
  end
  -- CUR1..CURn: a curried chain ((((fn f) a1) a2) ... an) whose (fn f) has
  -- already been evaluated to g (see curried_call in compiler.lua). Arity n:
  -- one direct call. Otherwise the original nested applications, verbatim.
  for n = 1, C.MAX_CALLN do
    local ps = {}
    for i = 1, n do ps[i] = "a" .. i end
    local nested = "g"
    for i = 1, n do nested = "APP(" .. nested .. ", a" .. i .. ")" end
    local src = "local FA, APP = ...\n"
      .. "return function(g, " .. table.concat(ps, ", ") .. ")\n"
      .. "  if FA[g] == " .. n .. " then return g(" .. table.concat(ps, ", ") .. ") end\n"
      .. "  return " .. nested .. "\n"
      .. "end\n"
    ENV["CUR" .. n] = assert((loadstring or load)(src, "=CUR" .. n))(FA, APP)
  end
end

-- PUC Lua 5.3+ tier: the inline fast paths must compute in the float domain
-- for the same int64-wrap reason as the `+`/`-`/`*`/`/` primitives above
-- (see that comment). Comparisons (GT/LT/GE/LE/EQ) create no numbers and are
-- exact across int/float in 5.3+, so they stay as-is. Under LuaJIT this
-- block is dead and ENV is byte-identical to before.
if math.tointeger then
  ENV.ADD = function(a,b) if type(a)=="number" and type(b)=="number" then return a+0.0+b end return F["+"](a,b) end
  ENV.SUB = function(a,b) if type(a)=="number" and type(b)=="number" then return a+0.0-b end return F["-"](a,b) end
  ENV.MUL = function(a,b) if type(a)=="number" and type(b)=="number" then return (a+0.0)*b end return F["*"](a,b) end
  ENV.DIV = function(a,b) if type(a)=="number" and type(b)=="number" and b~=0 then return (a+0.0)/b end return F["/"](a,b) end
end

local loadstring = loadstring or load
local setfenv = setfenv

-- Load Lua source OR a string.dump'd binary chunk into ENV without running it.
-- Used by compile_and_load and by the kernel bytecode cache (boot.lua).
local function load_chunk(code, chunkname)
  local chunk, err
  if setfenv then
    chunk, err = loadstring(code, chunkname)
    if not chunk then error("Lua load error in "..tostring(chunkname)..": "..tostring(err).."\n"..code) end
    setfenv(chunk, ENV)
  else
    chunk, err = load(code, chunkname, nil, ENV)
    if not chunk then error("Lua load error: "..tostring(err)) end
  end
  return chunk
end
P.load_chunk = load_chunk

-- hush-load quiet mode (issue #46 item 3). P.HUSH_LOAD_ECHO gates it
-- (bin/shen --hush-load, or SHEN_HUSH_LOAD=1); boot.lua wraps `load` to mark
-- the echo depth (P.LOADPR_DEPTH) and the native pr drops load's own
-- standard-output chatter at that depth. P.CHUNK_DEPTH counts the eval-kl
-- chunk nesting maintained by compile_and_load below. Unlike -q/*hush*
-- (which on the 42 kernel gates pr itself, i.e. ALL standard output),
-- hush-load leaves user (output ...)/pr from inside loaded forms alive.
P.CHUNK_DEPTH = 0
P.LOADPR_DEPTH = nil
do
  local hl = os.getenv("SHEN_HUSH_LOAD")
  P.HUSH_LOAD_ECHO = (hl == "1" or hl == "on" or hl == "true") or nil
end

-- P.FASL_REC: active fasl recording context (boot.lua's user-program cache).
-- While a (load ...) is being recorded, every TOP-LEVEL compile (a form the
-- kernel hands to eval-kl) is dumped into the record; compiles triggered
-- WHILE one of those chunks executes (nested eval-kl, e.g. compile-prolog
-- inside process-datatype) are not recorded — replaying the outer chunk
-- regenerates them naturally.
-- Lua limits the wide code shape avoids (compiler.lua, WIDE)
local function is_width_error(msg)
  msg = tostring(msg)
  return msg:find("has more than %d+ local variables") ~= nil
      or msg:find("has more than %d+ upvalues") ~= nil
      or msg:find("function or expression too complex", 1, true) ~= nil
end

-- defun_form: when the ordinary code for this defun exceeds a Lua limit,
-- recompile it in wide mode (loads that succeed never pay for this)
local function compile_and_load(luasrc, chunkname, defun_form)
  local fn
  if defun_form then
    local ok, res = pcall(load_chunk, luasrc, chunkname)
    if ok then
      fn = res
    elseif is_width_error(res) then
      fn = load_chunk(require("compiler").compile_top(defun_form, true), chunkname)
    else
      error(res, 0)
    end
  else
    fn = load_chunk(luasrc, chunkname)
  end
  local rec = P.FASL_REC
  if rec and not rec.in_chunk then
    rec.n = rec.n + 1
    rec[rec.n] = { k = "c", name = chunkname, dump = string.dump(fn) }
    rec.in_chunk = true
    P.CHUNK_DEPTH = P.CHUNK_DEPTH + 1
    local ok, res = pcall(fn)
    rec.in_chunk = false
    P.CHUNK_DEPTH = P.CHUNK_DEPTH - 1
    if not ok then error(res, 0) end
    return res
  end
  if P.HUSH_LOAD_ECHO then
    -- hush-load needs the chunk depth tracked even when fasl isn't recording
    -- (SHEN_FASL=off, or a nested eval-kl) so the pr gate above can tell
    -- `load`'s own echo (at the depth of load entry) from user output emitted
    -- inside a chunk. Only paid when the mode is on: the default path below
    -- stays a bare tail call.
    P.CHUNK_DEPTH = P.CHUNK_DEPTH + 1
    local ok, res = pcall(fn)
    P.CHUNK_DEPTH = P.CHUNK_DEPTH - 1
    if not ok then error(res, 0) end
    return res
  end
  return fn()
end
P.compile_and_load = compile_and_load

-- eval a single KL form (compile and run)
function P.eval(form)
  local C = require("compiler")
  -- Atoms and non-AST values self-evaluate. This includes numbers, strings,
  -- booleans, symbols, NIL, but also absvectors and streams that the macro
  -- expander may hand to (eval-kl) when walking property-vector entries.
  local t = type(form)
  if t == "number" or t == "string" or t == "boolean" then return form end
  if form == NIL then return form end
  if is_symbol(form) then
    -- Bare symbols evaluate to their value in the global var namespace if
    -- bound, otherwise to themselves (KL convention).
    local v = GLOBALS[form.name]
    if v ~= nil then return v end
    return form
  end
  if t == "table" and not is_cons(form) then
    -- absvector, stream, exception, or other opaque object: self-evaluating.
    return form
  end
  if is_cons(form) and is_symbol(form[1]) and form[1].name == "defun" then
    -- Chunkname carries the Shen function name ("shen:<fnname>") so Lua
    -- error positions and debug.traceback frames identify the Shen function
    -- (the REPL's Shen-level backtrace filters on this prefix; repl.lua).
    local nm = is_cons(form[2]) and is_symbol(form[2][1]) and form[2][1].name or "defun"
    compile_and_load(C.compile_top(form), "shen:" .. nm, form)
    return form[2][1]   -- the function NAME symbol (car of cdr), as shen-c returns
  end
  return compile_and_load(C.compile_expr_chunk(form), "eval")
end

return P
