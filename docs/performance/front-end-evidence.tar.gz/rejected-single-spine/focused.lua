-- Single-spine map agrees with the selected kernel on values and effects.
local shen=require('shen');shen.boot{quiet=true}
local R,C=require('runtime'),require('compiler');local P=shen.prims
local src=assert(io.open('klambda/sys.kl','rb')):read('*a')
local target
for _,form in ipairs(R.read_all(src)) do
 if R.is_cons(form) and form[1]==R.intern('defun') and form[2][1]==R.intern('shen.map-h') then target=form;break end
end
assert(target,'selected kernel map-h missing')
-- Change definition/call heads only; retain the error's original name.
local text=R.to_str(target):gsub("%(defun shen%.map%-h ","(defun spec.map-h "):gsub("%(shen%.map%-h ","(spec.map-h ")
local def=R.read_all(text)[1]
P.load_chunk(C.compile_top(def),'map-reference')()
local function ref(f,l) return P.F['spec.map-h'](f,l,R.NIL) end
local pass,fail=0,0
local function check(ok,label) if ok then pass=pass+1 else fail=fail+1;print('FAIL: '..label) end end
local function list(...)
 local args={...};local x=R.NIL;for i=#args,1,-1 do x=R.cons(args[i],x) end;return x
end
local function run(map,f,l)
 local effects={};local fn=function(x) effects[#effects+1]=R.to_str(x);return f(x) end;P.FA[fn]=1
 local ok,val=R.seg.pcall(map,fn,l)
 local text=ok and R.to_str(val) or P.F['error-to-string'](val)
 return ok,text,table.concat(effects,','),val
end
local inputs={R.NIL,list(1),list(1,2,3),R.cons(1,R.cons(2,R.intern('tail'))),R.intern('bad')}
for i,input in ipairs(inputs) do
 local a,b,c=run(P.F.map,function(x)return x+1 end,input)
 local d,e,f=run(ref,function(x)return x+1 end,input)
 check(a==d and b==e and c==f,'kernel values/errors/effects '..i)
end
local marker={};local effects={}
local function exploding(x) effects[#effects+1]=x;if x==2 then error(marker,0) end;return x end
P.FA[exploding]=1
local ok,err=R.seg.pcall(P.F.map,exploding,list(1,2,3))
check(not ok and err==marker and table.concat(effects,',')=='1,2','callback error identity and order')
P.F['spec.map-callback']=function(x)return x*2 end;P.FA[P.F['spec.map-callback']]=1
check(R.to_str(P.F.map(R.intern('spec.map-callback'),list(1,2)))=='(2 4)','symbol callback')
local partial=P.APP(P.F['+'],10)
check(R.to_str(P.F.map(partial,list(1,2)))=='(11 12)','partial callback')
local original=list(1,2,3);local identity=function(x)return x end;P.FA[identity]=1
local mapped=P.F.map(identity,original)
check(mapped~=original and mapped[2]~=original[2] and R.to_str(mapped)==R.to_str(original),'fresh output spine and unchanged input')
check(R.to_str(P.F['shen.map-h'](identity,list(3,4),list(2,1)))=='(1 2 3 4)','explicit map-h accumulator unchanged')
local deep=R.NIL;for i=1,20000 do deep=R.cons(i,deep) end
check(P.F.length(P.F.map(identity,deep))==20000,'long input does not grow Lua stack')
-- Callback replacement by name is observed on the next list element.
local calls=0
P.F['spec.map-changing']=function(x)
 calls=calls+1;P.F['spec.map-changing']=function(y)return y+10 end
 P.FA[P.F['spec.map-changing']]=1;return x
end
P.FA[P.F['spec.map-changing']]=1
check(R.to_str(P.F.map(R.intern('spec.map-changing'),list(1,2,3)))=='(1 12 13)' and calls==1,'callback redefinition observed during map')
print(string.format('map_spine_spec: %d pass, %d fail',pass,fail));os.exit(fail==0 and 0 or 1)
