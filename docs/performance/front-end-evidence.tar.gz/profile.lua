local P=require('boot');P.load_kernel(false);P.initialise()
local C,R,TN=require('compiler'),require('runtime'),require('typecheck_native')
TN.ensure_drivers();P.HUSH_LOAD_ECHO=true
local stats={}
local function wrap(t,k,label)
 local orig=assert(t[k],k);local s={cpu=0,calls=0};stats[label]=s
 t[k]=function(...)
  local start=os.clock();local result=orig(...)
  s.cpu=s.cpu+os.clock()-start;s.calls=s.calls+1
  return result
 end
 if t==P.F then P.FA[t[k]]=P.FA[orig] end
end
for _,name in ipairs({'read-file','shen.process-sexprs','macroexpand','shen.source-macro-walk','shen.shen->kl','shen.record-and-evaluate','shen.typecheck'}) do wrap(P.F,name,name) end
wrap(C,'compile_top','lua_codegen_defun');wrap(C,'compile_expr_chunk','lua_codegen_expr')
wrap(P,'load_chunk','lua_compile')
for i=1,100 do
 local name=debug.getupvalue(P.compile_and_load,i)
 if not name then break end
 if name=='load_chunk' then debug.setupvalue(P.compile_and_load,i,P.load_chunk);break end
end
local jp=require('jit.p');jp.start('vfl',arg[1] or '.work/front-end/load.profile')
for _,path in ipairs({'tests/interpreter.shen','tests/calculator.shen','bench/fixtures/parser.shen'}) do
 P.GLOBALS['shen.*tc*']=true;P.GLOBALS['shen.*infs*']=0
 local start=os.clock();P.F.load(path)
 print('TYPED_LOAD',path,os.clock()-start,P.GLOBALS['shen.*infs*'])
end
jp.stop()
print('DIAGNOSTIC',require('bench.typecheck_harness').json(stats))
