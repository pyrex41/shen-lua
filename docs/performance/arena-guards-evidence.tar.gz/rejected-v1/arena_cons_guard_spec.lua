-- Arena shape tests must equal cons? on the fully materialized root without
-- copying its children. Cover bindings, opaque atoms and translator eligibility.
package.path = (arg[0]:gsub('test/[^/]*$', '')) .. '?.lua;' .. package.path
local shen = require('shen'); shen.boot{quiet=true}
local R, E, PC = require('runtime'), require('prolog_engine'), require('prolog_compile')
local C = require('compiler'); local P = shen.prims
local pass, fail = 0, 0
local function check(ok, label)
 if ok then pass=pass+1 else fail=fail+1; print('FAIL: '..label) end
end
local function translated(test)
 return PC.translate_defun(R.read_all('(defun spec.noncons (V1 V2 V3 V4 V5) (when '..test..' V2 V3 V4 (freeze true)))')[1])
end
local fn, err, src = translated('(not (cons? (shen.deref V1 V2)))')
check(fn ~= nil, 'exact deref shape translates: '..tostring(err))
check(src and src:find('CONSPTERM(a1)',1,true), 'eligible guard uses arena root shape')
check(src and not src:find('MAT(',1,true), 'eligible guard materializes nothing')
local bare, why, bsrc = translated('(not (cons? V1))')
check(bare ~= nil and bsrc:find('CONSPTERM(a1)',1,true), 'bare term shape: '..tostring(why))
local q=E.query_begin()
local v=E.newvar(); local chain=E.newvar();local list=E.import(R.read_all('(a (b c) . d)')[1],{})
local opaque=E.atom(R.cons(1,R.NIL))
local samples={E.import(R.NIL,{}),E.import(1,{}),E.import('text',{}),E.import(true,{}),E.import(false,{}),
 E.import(R.intern('X'),{}),E.import(P.F.vector(0),{}),list,E.cons(v,chain),v,chain,opaque}
for _,term in ipairs(samples) do
 local want=R.is_cons(E.materialize(term))
 check(E.cons_term(term)==want,'root agrees for term '..term)
 if fn and bare then
  check(fn(term,0,nil)==not want and bare(term,0,nil)==not want,'translated guards agree for term '..term)
 end
end
E.bind1(chain,list,function()
 E.bind1(v,chain,function()
  check(E.cons_term(v) and fn(v,0,nil)==false,'bound variable chain resolves to list')
  return false
 end)
 return false
end)
check(not E.cons_term(v),'binding rollback restores unbound shape')
-- A long term with unbound leaves must be classified from its root only.
local long=v;for i=1,10000 do long=E.cons(v,long) end
check(E.cons_term(long) and fn(long,0,nil)==false,'long open list needs no deep materialization')
E.query_end(q)
-- Existing compiler primitive inlining applies only at exact declared arity.
-- Guards outside that contract must retain ordinary materialized dispatch.
for _,name in ipairs({'cons?','not'}) do
 local old=C.ARITY[name];C.ARITY[name]=2
 local fallback, e, code=translated('(not (cons? (shen.deref V1 V2)))')
 C.ARITY[name]=old
 check(fallback ~= nil and code:find('MAT(',1,true) and not code:find('CONSPTERM(',1,true),name..' changed arity uses lifted guard: '..tostring(e))
end
-- Malformed extra arguments must not be optimized as the exact guard.
local _, _, malformed=translated('(not (cons? (shen.deref V1 V2) true))')
check(not malformed or not malformed:find('CONSPTERM(',1,true),'extra cons? argument is not optimized')
local _, _, wrongvec=translated('(not (cons? (shen.deref V1 V1)))')
check(not wrongvec or not wrongvec:find('CONSPTERM(',1,true),'non-vector deref argument is not optimized')
print(string.format('arena_cons_guard_spec: %d pass, %d fail',pass,fail))
os.exit(fail==0 and 0 or 1)
