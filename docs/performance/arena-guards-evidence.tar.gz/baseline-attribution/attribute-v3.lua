local P=require('boot'); local R=require('runtime'); local E=require('prolog_engine')
local PC=require('prolog_compile');local sources={};local trans=PC.translate_defun
PC.translate_defun=function(form,...)
 local fn,err,src,why,callees=trans(form,...)
 if src then sources[tostring(form[2][1])]=src end
 return fn,err,src,why,callees
end
local original=P.eval
local forms={}
P.eval=function(form,...)
 if R.is_cons(form) and form[1]==R.intern('defun') then
  local name=tostring(form[2][1]); if name:match('^shen.lua%-guard%-') then forms[name]=R.to_str(form) end
 end
 return original(form,...)
end
local active=false;local rows={};local origmat=E.materialize
E.materialize=function(x,...)
 if active then
  local loc=debug.getinfo(2,'Sl');local k=loc.short_src..':'..loc.currentline
  rows[k]=(rows[k] or 0)+1
 end
 return origmat(x,...)
end
local report=require('bench.typecheck_harness').run('time')
local queries={}
for _,s in ipairs(require('bench.typecheck_corpus')) do for _,c in ipairs(s.cases) do
 if c[1]~='interpreter-y-inferred' then
  local f=P.F['read-from-string'](c[2]..' : '..c[3]);queries[#queries+1]={f[1],f[2][2][1]}
 end
end end
active=true
for round=1,100 do for _,q in ipairs(queries) do P.GLOBALS['shen.*infs*']=0;R.seg.call(P.F['shen.typecheck'],q[1],q[2]) end end
active=false
local sorted={};for k,n in pairs(rows) do sorted[#sorted+1]={k,n} end;table.sort(sorted,function(a,b)return a[2]>b[2]end)
local PC=require('prolog_compile')
for i=1,math.min(#sorted,40) do
 local k,n=unpack(sorted[i]);print('MAT',k,n)
 local name,line=k:match('prolog:(.*):(%d+)$');local src=name and (sources[name] or (PC.registry[name] and PC.registry[name].src))
 if src then local pos=0;for l in (src..'\n'):gmatch('(.-)\n') do pos=pos+1;if pos==tonumber(line) then print('SOURCE',l) end end end
end
for n,s in pairs(forms) do print('GUARD',n,s) end
