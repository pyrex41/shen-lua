from pathlib import Path
import hashlib,json,os,resource,statistics,subprocess,time
r=Path.cwd();base=r.parent/'shen-lua-issue98';out=r/'.work/arena-guards/colon-bundle';out.mkdir(exist_ok=False)
def identity(root):
 files=[*root.glob('*.lua'),*root.glob('klambda/*.kl'),*root.glob('bench/*.lua')]
 files += [root/('.work/arena-guards/shen.lua' if root==r else '.work/issue98/default-upstream/shen.lua')]
 return dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},diff=subprocess.check_output(['git','diff','HEAD'],cwd=root,text=True))
before={k:identity(v) for k,v in [('base',base),('candidate',r)]};(out/'identity-before.json').write_text(json.dumps(before,indent=2)+'\n')
rows=[]
for i in range(7):
 for mode,root in ([('base',base),('candidate',r)] if i%2==0 else [('candidate',r),('base',base)]):
  env={k:v for k,v in os.environ.items() if not k.startswith('SHEN_')};env.update(SHEN_KERNEL_CACHE='off',SHEN_FASL='off',SHEN_TYPECHECK_NATIVE='require',SHEN_BENCH_REPEATS='51',SHEN_BENCH_BUNDLE=str(root/('.work/arena-guards/shen.lua' if root==r else '.work/issue98/default-upstream/shen.lua')))
  label=f'{i:02d}-{mode}';start=time.monotonic();prev=resource.getrusage(resource.RUSAGE_CHILDREN)
  proc=subprocess.run(['luajit','bench/typecheck_time.lua'],cwd=root,env=env,capture_output=True,timeout=120)
  end=resource.getrusage(resource.RUSAGE_CHILDREN);(out/(label+'.stdout')).write_bytes(proc.stdout);(out/(label+'.stderr')).write_bytes(proc.stderr)
  assert proc.returncode==0,label
  report=json.loads(next(x[16:] for x in proc.stdout.decode().splitlines() if x.startswith('SHEN_BENCH_JSON ')))
  assert all(q['ok'] and q['route']['engine']=='native' for q in report['queries']);assert len(report['queries'])==1020
  row=dict(pair=i,mode=mode,report=report,wall=time.monotonic()-start,cpu=end.ru_utime+end.ru_stime-prev.ru_utime-prev.ru_stime,load=os.getloadavg(),settings={k:v for k,v in env.items() if k.startswith('SHEN_')})
  row['metrics']={name:sum(q['cpu'] for q in report['queries'] if pred(q)) for name,pred in dict(first=lambda q:q['request']==1,persistent=lambda q:q['request']>1,small=lambda q:q['request']>1 and q['name']!='interpreter-y-inferred',heavy=lambda q:q['request']>1 and q['name']=='interpreter-y-inferred').items()}
  row['metrics']['load']=sum(x['cpu'] for x in report['loads']);(out/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(label,row['metrics'],flush=True)
  ref=[(q['name'],q['request'],q['result'],q['inferences']) for q in report['queries']]
  if len(rows)>1:assert ref==[(q['name'],q['request'],q['result'],q['inferences']) for q in rows[0]['report']['queries']]
after={k:identity(v) for k,v in [('base',base),('candidate',r)]};assert all(before[m]["files"]==after[m]["files"] for m in before)
(out/'identity-after.json').write_text(json.dumps(after,indent=2)+'\n');summary={}
for metric in rows[0]['metrics']:
 values={mode:[x['metrics'][metric] for x in rows if x['mode']==mode] for mode in ['base','candidate']};rat=[b/c for b,c in zip(values['base'],values['candidate'])]
 summary[metric]=dict(samples=values,median_speedup=statistics.median(rat),ratios=rat)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
