from pathlib import Path
import gzip,hashlib,io,json,re,statistics,tarfile
root=Path.cwd();work=root/'.work/arena-guards';docs=root/'docs/performance'
def read(path):return json.loads((work/path).read_text())
accepted={label:read(label+'/summary.json') for label in ['colon','colon-repeat','colon-bundle']}
rejected={label:read(label+'/summary.json') for label in ['pilot-v2','protected','protected-repeat']}
rejected['pilot']=read('pilot/summary-recovered.json')
ratios=[v for label in ['colon','colon-repeat'] for v in accepted[label]['persistent']['ratios']]
alloc={}
for group in ['all','smaller','heavy']:
 vals={}
 for mode in ['base','candidate']:
  vals[mode]=[]
  for f in sorted((work/'colon-alloc').glob('*-'+mode+'.json')):
   qs=json.loads(f.read_text())['report']['queries']
   vals[mode].append(sum(q['allocated_bytes'] for q in qs if q['request']>1 and
    (group!='smaller' or q['name']!='interpreter-y-inferred') and
    (group!='heavy' or q['name']=='interpreter-y-inferred')))
 alloc[group]=dict(samples=vals,candidate_over_base=[c/b for b,c in zip(vals['base'],vals['candidate'])])
meta=dict(baseline_commit='908b25d',runtime_commit='5b74916',kernel='ec16a9fa4fc2e87e2aa336fb1ae30e8ac2266394',
 accepted=accepted,source_pooled=dict(median_speedup=statistics.median(ratios),wins=sum(r>1 for r in ratios),pairs=len(ratios)),
 rejected=rejected,allocation_diagnostic=alloc,scheme_final=read('scheme-final/summary.json'),
 validation=dict(port_checks=1855,specs=33,kernel_checks=154,strict_native_kernel=154,pure_kl_kernel=154,
 puc54_golden=20,source_and_bundle_caches=['off','cold','hit'],standalone_bundle=True),
 limitations=['Uncontrolled host; retain all outliers and phase-specific ratios',
 'Smaller-query speedup was not consistent across repeat cohorts',
 'No meaningful measured reduction in Lua heap growth; FFI allocations excluded',
 'Refreshed Scheme comparison is a separate cohort; no ratio-of-historical-ratios claim'])
(docs/'arena-guards-statistics.json').write_text(json.dumps(meta,indent=2)+'\n')
# Bind the portable archive to the exact runners and rejected implementations.
(work/'compare_lua.py').write_bytes((root/'bench/compare_lua.py').read_bytes())
allowed={'.json','.stdout','.stderr','.log','.diff','.py','.lua','.md','.profile'}
files=[p for p in sorted(work.rglob('*')) if p.is_file() and p.suffix in allowed
 and p.name!='shen.lua' and not p.is_symlink() and 'validation' not in p.relative_to(work).parts
 and '__pycache__' not in p.parts]
archive=docs/'arena-guards-evidence.tar.gz';index=[]
with archive.open('wb') as output,gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in files:
  raw=p.read_bytes()
  try:txt=raw.decode()
  except UnicodeDecodeError:continue
  txt=txt.replace(str(root),'<candidate-repo>').replace(str(root.parent/'shen-lua-issue98'),'<baseline-repo>').replace(str(Path.home()),'<home>')
  txt=re.sub(r'/(?:private/)?var/folders/[^\s"\'\\]+','<private-temp>',txt)
  assert '<home>' not in txt
  data=txt.encode();name=str(p.relative_to(work));index.append(dict(file=name,original_sha256=hashlib.sha256(raw).hexdigest(),portable_sha256=hashlib.sha256(data).hexdigest()))
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 data=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('index.json');info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(docs/'arena-guards-evidence.sha256').write_text(sha+'  '+archive.name+'\n')
print(len(index),'portable receipts;',archive.stat().st_size,'bytes;',sha)
